export type RegistrationField = 'name' | 'username' | 'email' | 'password' | 'confirmPassword';

export type FieldErrors = Partial<Record<RegistrationField, string>>;

export interface RegistrationValues {
  name: string;
  username: string;
  email: string;
}

export const PASSWORD_RULES = [
  {
    id: 'length',
    label: 'At least 8 characters',
    test: (pw: string) => typeof pw === 'string' && pw.length >= 8,
  },
  {
    id: 'lowercase',
    label: 'One lowercase letter',
    test: (pw: string) => typeof pw === 'string' && /[a-z]/.test(pw),
  },
  {
    id: 'uppercase',
    label: 'One uppercase letter',
    test: (pw: string) => typeof pw === 'string' && /[A-Z]/.test(pw),
  },
  {
    id: 'number',
    label: 'One number',
    test: (pw: string) => typeof pw === 'string' && /[0-9]/.test(pw),
  },
  {
    id: 'special',
    label: 'One special character',
    test: (pw: string) => typeof pw === 'string' && /[^a-zA-Z0-9]/.test(pw),
  },
];

export function validateName(name: string): string | null {
  if (typeof name !== 'string' || !name.trim()) {
    return 'Full name is required.';
  }
  const trimmed = name.trim();
  if (trimmed.length < 2) {
    return 'Full name must be at least 2 characters.';
  }
  if (trimmed.length > 60) {
    return 'Full name must be 60 characters or fewer.';
  }
  const nameRegex = /^[\p{L}][\p{L}\s'.-]*$/u;
  if (!nameRegex.test(trimmed)) {
    return 'Full name can only contain letters, spaces, hyphens, periods, and apostrophes.';
  }
  return null;
}

export function validateUsername(username: string): string | null {
  if (typeof username !== 'string' || !username.trim()) {
    return 'Username is required.';
  }
  const trimmed = username.trim();
  if (trimmed.length < 3 || trimmed.length > 20) {
    return 'Username must be 3–20 characters.';
  }
  if (!/^[a-zA-Z0-9_]+$/.test(trimmed)) {
    return 'Username can only contain letters, numbers and underscores.';
  }
  return null;
}

export function validateEmail(email: string): string | null {
  if (typeof email !== 'string' || !email.trim()) {
    return 'Email address is required.';
  }
  const trimmed = email.trim();
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)+$/;
  if (!emailRegex.test(trimmed)) {
    return 'Enter a valid email address.';
  }
  return null;
}

export function validatePassword(password: string): string | null {
  if (typeof password !== 'string' || !password) {
    return 'Password is required.';
  }
  if (password.length < 8) {
    return 'Password must be at least 8 characters.';
  }
  const byteLen = typeof Buffer !== 'undefined'
    ? Buffer.byteLength(password, 'utf8')
    : new TextEncoder().encode(password).length;
  if (byteLen > 72) {
    return 'Password must be 72 bytes or fewer.';
  }
  if (!/[a-z]/.test(password)) {
    return 'Password must contain at least one lowercase letter.';
  }
  if (!/[A-Z]/.test(password)) {
    return 'Password must contain at least one uppercase letter.';
  }
  if (!/[0-9]/.test(password)) {
    return 'Password must contain at least one number.';
  }
  if (!/[^a-zA-Z0-9]/.test(password)) {
    return 'Password must contain at least one special character.';
  }
  return null;
}

export function validateConfirmPassword(password: string, confirmPassword: string): string | null {
  if (typeof confirmPassword !== 'string' || !confirmPassword) {
    return 'Please confirm your password.';
  }
  if (password !== confirmPassword) {
    return 'Passwords do not match.';
  }
  return null;
}

export function normalizeName(name: string): string {
  return typeof name === 'string' ? name.trim().replace(/\s+/g, ' ') : '';
}

export function normalizeUsername(username: string): string {
  return typeof username === 'string' ? username.trim().toLowerCase() : '';
}

export function normalizeEmail(email: string): string {
  return typeof email === 'string' ? email.trim().toLowerCase() : '';
}

export function validateRegistration(data: any): {
  valid: boolean;
  errors: FieldErrors;
  values: RegistrationValues;
} {
  const name = typeof data?.name === 'string' ? data.name : '';
  const username = typeof data?.username === 'string' ? data.username : '';
  const email = typeof data?.email === 'string' ? data.email : '';
  const password = typeof data?.password === 'string' ? data.password : '';
  const confirmPassword = typeof data?.confirmPassword === 'string' ? data.confirmPassword : '';

  const errors: FieldErrors = {};

  const nameError = validateName(name);
  if (nameError) errors.name = nameError;

  const usernameError = validateUsername(username);
  if (usernameError) errors.username = usernameError;

  const emailError = validateEmail(email);
  if (emailError) errors.email = emailError;

  const passwordError = validatePassword(password);
  if (passwordError) errors.password = passwordError;

  const confirmError = validateConfirmPassword(password, confirmPassword);
  if (confirmError) errors.confirmPassword = confirmError;

  return {
    valid: Object.keys(errors).length === 0,
    errors,
    values: {
      name: normalizeName(name),
      username: normalizeUsername(username),
      email: normalizeEmail(email),
    },
  };
}
