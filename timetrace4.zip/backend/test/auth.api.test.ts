import { after, before, describe, it } from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import type { AddressInfo } from 'node:net';
import type { Server } from 'node:http';

// Isolate all data in a throwaway directory. This must be set before the app modules load,
// because config/env.ts reads CHRONOTRACE_DATA_DIR at import time.
const dataDir = fs.mkdtempSync(path.join(os.tmpdir(), 'chronotrace-test-'));
process.env.CHRONOTRACE_DATA_DIR = dataDir;
delete process.env.GOOGLE_CLIENT_ID;

const usersFile = path.join(dataDir, 'users.json');
const sessionsFile = path.join(dataDir, 'auth_sessions.json');

let server: Server;
let base = '';

interface Reply {
  status: number;
  body: any;
  cookie: string | null;
  setCookieHeader: string | null;
  contentType: string;
}

async function call(method: string, url: string, options: { body?: unknown; cookie?: string | null; raw?: string } = {}): Promise<Reply> {
  const headers: Record<string, string> = {};
  if (options.body !== undefined || options.raw !== undefined) headers['Content-Type'] = 'application/json';
  if (options.cookie) headers.Cookie = `chronotrace_session=${options.cookie}`;
  const res = await fetch(base + url, {
    method,
    headers,
    body: options.raw ?? (options.body !== undefined ? JSON.stringify(options.body) : undefined),
  });
  const text = await res.text();
  let body: any = text;
  try {
    body = text ? JSON.parse(text) : null;
  } catch {
    // Keep the raw text so a test can show what came back.
  }
  const setCookieHeader = res.headers.get('set-cookie');
  const match = setCookieHeader?.match(/chronotrace_session=([^;]+)/);
  return {
    status: res.status,
    body,
    cookie: match ? match[1] : null,
    setCookieHeader,
    contentType: res.headers.get('content-type') || '',
  };
}

const alex = {
  name: 'Alex Morgan',
  username: 'alex_morgan',
  email: 'alex@example.com',
  password: 'Secret123!',
  confirmPassword: 'Secret123!',
};

before(async () => {
  const { app } = await import('../src/app.js');
  server = app.listen(0, '127.0.0.1');
  await new Promise<void>((resolve) => server.once('listening', () => resolve()));
  const { port } = server.address() as AddressInfo;
  base = `http://127.0.0.1:${port}`;
});

after(() => {
  server?.close();
  fs.rmSync(dataDir, { recursive: true, force: true });
});

describe('public configuration', () => {
  it('reports that Google sign-in is off when GOOGLE_CLIENT_ID is not set', async () => {
    const res = await call('GET', '/api/auth/config');
    assert.equal(res.status, 200);
    assert.equal(res.body.googleClientId, null);
    assert.equal(res.body.googleEnabled, false);
  });

  it('returns 503 with a setup message from Google sign-in when not configured', async () => {
    const res = await call('POST', '/api/auth/google', { body: { credential: 'anything' } });
    assert.equal(res.status, 503);
    assert.equal(res.body.code, 'GOOGLE_NOT_CONFIGURED');
    assert.match(res.body.error, /GOOGLE_CLIENT_ID/);
  });
});

describe('protected routes', () => {
  it('rejects data routes without a session with a JSON 401', async () => {
    for (const url of ['/api/device/status', '/api/summary/today', '/api/sessions', '/summary']) {
      const res = await call('GET', url);
      assert.equal(res.status, 401, `${url} should require a session`);
      assert.match(res.contentType, /application\/json/);
      assert.equal(res.body.error, 'Sign in required.');
    }
  });

  it('reports an anonymous session as unauthenticated', async () => {
    const res = await call('GET', '/api/auth/session');
    assert.equal(res.status, 200);
    assert.equal(res.body.authenticated, false);
    assert.equal(res.body.user, null);
  });
});

describe('registration', () => {
  it('rejects invalid input with per-field errors and stores nothing', async () => {
    const res = await call('POST', '/api/auth/register', {
      body: { name: '', username: 'a', email: 'nope', password: 'weak', confirmPassword: 'x' },
    });
    assert.equal(res.status, 400);
    assert.deepEqual(Object.keys(res.body.fieldErrors).sort(), ['confirmPassword', 'email', 'name', 'password', 'username']);
    assert.equal(fs.existsSync(usersFile), false);
  });

  it('creates an account, sets an httpOnly session cookie and does not expose the token in the body', async () => {
    const res = await call('POST', '/api/auth/register', { body: alex });
    assert.equal(res.status, 201);
    assert.ok(res.cookie, 'session cookie should be set');
    assert.match(res.setCookieHeader ?? '', /HttpOnly/i);
    assert.match(res.setCookieHeader ?? '', /SameSite=Lax/i);
    assert.equal(res.body.token, undefined, 'the session token must not be returned to JavaScript');
    assert.equal(res.body.user.username, 'alex_morgan');
    assert.equal(res.body.isRegistered, false);

    const stored = JSON.parse(fs.readFileSync(usersFile, 'utf-8'));
    assert.equal(stored.length, 1);
    assert.match(stored[0].passwordHash, /^\$2[aby]\$10\$/, 'password must be stored as a bcrypt hash');
    assert.notEqual(stored[0].passwordHash, alex.password);
  });

  it('rejects a duplicate username regardless of case with 409 and a field error', async () => {
    const res = await call('POST', '/api/auth/register', {
      body: { ...alex, username: 'ALEX_Morgan', email: 'other@example.com' },
    });
    assert.equal(res.status, 409);
    assert.match(res.body.fieldErrors.username, /already taken/);
  });

  it('rejects a duplicate email regardless of case with 409 and a field error', async () => {
    const res = await call('POST', '/api/auth/register', {
      body: { ...alex, username: 'someone_else', email: 'ALEX@example.com' },
    });
    assert.equal(res.status, 409);
    assert.match(res.body.fieldErrors.email, /already exists/);
  });

  it('keeps the password exactly as typed: a leading space is part of the password', async () => {
    const spaced = { ...alex, username: 'spaced_user', email: 'spaced@example.com', password: ' Secret123!', confirmPassword: ' Secret123!' };
    const created = await call('POST', '/api/auth/register', { body: spaced });
    assert.equal(created.status, 201);

    const withoutSpace = await call('POST', '/api/auth/login', { body: { username: 'spaced_user', password: 'Secret123!' } });
    assert.equal(withoutSpace.status, 401, 'a password missing its leading space must not match');

    const exact = await call('POST', '/api/auth/login', { body: { username: 'spaced_user', password: ' Secret123!' } });
    assert.equal(exact.status, 200);
  });
});

describe('login', () => {
  it('signs in with username in any case', async () => {
    const res = await call('POST', '/api/auth/login', { body: { username: '  ALEX_morgan ', password: alex.password } });
    assert.equal(res.status, 200);
    assert.equal(res.body.success, true);
    assert.equal(res.body.user.email, 'alex@example.com');
    assert.ok(res.cookie);
  });

  it('signs in with the email address', async () => {
    const res = await call('POST', '/api/auth/login', { body: { username: 'Alex@Example.com', password: alex.password } });
    assert.equal(res.status, 200);
    assert.equal(res.body.user.username, 'alex_morgan');
  });

  it('returns the same 401 for a wrong password and for an unknown account', async () => {
    const wrong = await call('POST', '/api/auth/login', { body: { username: 'alex_morgan', password: 'Wrong123!' } });
    const unknown = await call('POST', '/api/auth/login', { body: { username: 'nobody_here', password: 'Wrong123!' } });
    assert.equal(wrong.status, 401);
    assert.equal(unknown.status, 401);
    assert.equal(wrong.body.error, unknown.body.error);
    assert.equal(wrong.cookie, null);
  });

  it('returns a clear 400 when fields are missing', async () => {
    const res = await call('POST', '/api/auth/login', { body: { username: 'alex_morgan' } });
    assert.equal(res.status, 400);
    assert.match(res.body.error, /username or email and password/);
  });

  it('returns a JSON error, not an HTML page, for a malformed request body', async () => {
    const res = await call('POST', '/api/auth/login', { raw: '{"username": ' });
    assert.equal(res.status, 400);
    assert.match(res.contentType, /application\/json/);
    assert.equal(res.body.error, 'The request body must be valid JSON.');
  });
});

describe('session persistence and logout', () => {
  let cookie: string;

  it('keeps the user signed in across requests with the cookie', async () => {
    const login = await call('POST', '/api/auth/login', { body: { username: 'alex_morgan', password: alex.password } });
    cookie = login.cookie!;

    const session = await call('GET', '/api/auth/session', { cookie });
    assert.equal(session.body.authenticated, true);
    assert.equal(session.body.user.username, 'alex_morgan');

    const protectedRes = await call('GET', '/api/device/status', { cookie });
    assert.equal(protectedRes.status, 200);
  });

  it('records completed device setup so it survives a later session check', async () => {
    const done = await call('POST', '/api/auth/complete-device-setup', { cookie });
    assert.equal(done.status, 200);

    const session = await call('GET', '/api/auth/session', { cookie });
    assert.equal(session.body.isRegistered, true);
    assert.equal(session.body.hasConfiguredDevice, true);
  });

  it('logout clears the cookie and revokes the server-side session', async () => {
    const out = await call('POST', '/api/auth/logout', { cookie });
    assert.equal(out.status, 200);
    assert.match(out.setCookieHeader ?? '', /chronotrace_session=;.*Expires=/i);

    const after = await call('GET', '/api/auth/session', { cookie });
    assert.equal(after.body.authenticated, false);

    const blocked = await call('GET', '/api/device/status', { cookie });
    assert.equal(blocked.status, 401, 'an old cookie must stop working after logout');
  });
});

describe('regressions found while reproducing the sign-in failure', () => {
  it('a legacy record without an email does not break sign-in for other accounts', async () => {
    // Pre-Phase-1 files could contain records missing email or username. Before the fix,
    // a lookup that reached such a record threw and every sign-in returned a 500.
    const users = JSON.parse(fs.readFileSync(usersFile, 'utf-8'));
    users.push({ id: 'usr_legacy_1', username: 'legacy_user', password: 'password123' });
    fs.writeFileSync(usersFile, JSON.stringify(users, null, 2));

    const res = await call('POST', '/api/auth/login', { body: { username: alex.username, password: alex.password } });
    assert.equal(res.status, 200, 'valid credentials must still sign in');

    const legacy = await call('POST', '/api/auth/login', { body: { username: 'legacy_user', password: 'password123' } });
    assert.equal(legacy.status, 200, 'a legacy plain password is migrated and verified');
  });

  it('a corrupt users.json fails closed and is never overwritten by registration', async () => {
    const corrupt = '[{"id":"usr_real","username":"realowner"';
    fs.writeFileSync(usersFile, corrupt);

    const res = await call('POST', '/api/auth/register', {
      body: { ...alex, username: 'brand_new', email: 'brand_new@example.com' },
    });
    assert.equal(res.status, 500);
    assert.match(res.contentType, /application\/json/);
    assert.equal(fs.readFileSync(usersFile, 'utf-8'), corrupt, 'the damaged file must be left untouched');

    const login = await call('POST', '/api/auth/login', { body: { username: 'alex_morgan', password: alex.password } });
    assert.equal(login.status, 500, 'sign-in must not pretend the account does not exist');
  });
});
