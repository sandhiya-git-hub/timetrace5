import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import { app } from './backend/src/app.js';
import { PORT } from './backend/src/config/env.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

import fs from 'fs';
import { exec } from 'child_process';

const isProduction =
  process.env.NODE_ENV === 'production' || process.argv.includes('--production');

function ensureNginxApiBypass() {
  const confPath = '/etc/nginx/nginx.conf';
  try {
    if (!fs.existsSync(confPath)) return;
    let conf = fs.readFileSync(confPath, 'utf8');
    if (!conf.includes('location /api/')) {
      const apiBlock = `        # ChronoTrace direct API proxy for collector agent
        location /api/ {
            proxy_pass http://localhost:3000;
            proxy_set_header Host localhost:3000;
            proxy_set_header X-Forwarded-Host $host;
            proxy_set_header X-Real-IP $remote_addr;
            proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
            proxy_set_header X-Forwarded-Proto $scheme;
        }

        # Serve the app for all other paths.`;
      conf = conf.replace('        # Serve the app for all other paths.', apiBlock);
      fs.writeFileSync(confPath, conf, 'utf8');
      exec('nginx -t && nginx -s reload', (err) => {
        if (!err) {
          console.log('[nginx] Dynamically ensured /api/ proxy block in /etc/nginx/nginx.conf');
        }
      });
    }
  } catch (err) {
    // Non-fatal if container environment restricts nginx
  }
}

async function startServer() {
  ensureNginxApiBypass();
  if (!isProduction) {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.resolve(__dirname, 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req, res) => {
      res.sendFile(path.resolve(distPath, 'index.html'));
    });
  }

  const port = Number(PORT) || 3000;
  app.listen(port, '0.0.0.0', () => {
    console.log(`ChronoTrace server listening on http://0.0.0.0:${port}`);
  });
}

startServer();
