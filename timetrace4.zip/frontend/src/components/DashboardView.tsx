import React, { useState, useEffect, useMemo } from 'react';
import { DateRangePicker, DateRangeSelection } from './DateRangePicker';
import {
  DailySynthesis,
  ChunkSummary,
  ReentryBriefing,
  UserProfile,
  TelemetryEvent,
  DeviceState,
} from '@shared/types/chronotrace';
import {
  Laptop,
  AlertCircle,
  CheckCircle2,
  XCircle,
  RefreshCw,
  ArrowRight,
  Shield,
  HelpCircle,
  Sparkles,
  Clock,
  Compass,
  Radio,
  Layers,
  Activity,
  TrendingUp,
  BarChart3,
  Info,
  X,
} from 'lucide-react';
import { apiFetch } from '../lib/api';

interface DashboardViewProps {
  user: UserProfile | null;
  device?: DeviceState | null;
  summary: DailySynthesis | null;
  chunks: ChunkSummary[];
  events?: TelemetryEvent[];
  reentry: ReentryBriefing | null;
  onRefreshSummary?: () => void;
  isSynthesizing?: boolean;
  onNavigateToTimeline?: () => void;
  onNavigateToAssistant?: (prompt?: string) => void;
  onOpenDeviceModal?: () => void;
}

export const DashboardView: React.FC<DashboardViewProps> = ({
  user,
  device,
  summary: initialSummary,
  chunks = [],
  events = [],
  reentry,
  onRefreshSummary,
  isSynthesizing = false,
  onNavigateToTimeline,
  onNavigateToAssistant,
  onOpenDeviceModal,
}) => {
  const [hoveredEvent, setHoveredEvent] = useState<string | null>(null);
  const [selectedTimelineItem, setSelectedTimelineItem] = useState<{
    app_name: string;
    window_title: string;
    category: string;
    dwell_ms: number;
    timestamp: string;
    date?: string;
  } | null>(null);

  const displayEvents = useMemo(() => {
    if (!events || events.length === 0) return [];
    return events;
  }, [events]);

  const totalDwell = useMemo(() => {
    return displayEvents.reduce((acc, e) => acc + (e.dwell_ms || 2000), 0);
  }, [displayEvents]);

  const hasData = displayEvents.length > 0 || chunks.length > 0;
  const isDeviceConnected = device?.connected === true;
  const hasIncomingEvents = displayEvents.length > 0;

  // Real current date from live events, server synthesis, or browser locale
  const initialDateStr = useMemo(() => {
    if (initialSummary?.date) return initialSummary.date;
    if (displayEvents.length > 0) {
      const last = displayEvents[displayEvents.length - 1];
      if (last.date) return last.date;
      if (last.recorded_at) return new Date(last.recorded_at).toLocaleDateString('en-CA');
    }
    return new Date().toLocaleDateString('en-CA');
  }, [initialSummary, displayEvents]);

  const [dateRange, setDateRange] = useState<DateRangeSelection>({
    type: 'today',
    label: 'Today',
    startDate: initialDateStr,
    endDate: initialDateStr,
  });

  const [activeSummary, setActiveSummary] = useState<DailySynthesis | null>(initialSummary);
  const [isFetching, setIsFetching] = useState<boolean>(false);

  // Sync initial summary if provided
  useEffect(() => {
    if (initialSummary && dateRange.type === 'today') {
      setActiveSummary(initialSummary);
    }
  }, [initialSummary]);

  // Keep date aligned with actual event dates
  useEffect(() => {
    if (initialDateStr && dateRange.type === 'today') {
      setDateRange((prev) => ({
        ...prev,
        startDate: initialDateStr,
        endDate: initialDateStr,
      }));
    }
  }, [initialDateStr]);

  const handleDateRangeChange = async (newRange: DateRangeSelection) => {
    setDateRange(newRange);
    setIsFetching(true);
    try {
      const params = new URLSearchParams({
        range: newRange.type,
        ...(newRange.startDate && { startDate: newRange.startDate }),
        ...(newRange.endDate && { endDate: newRange.endDate }),
      });
      const res = await apiFetch(`/api/summary?${params.toString()}`);
      if (res.ok) {
        const data = await res.json();
        setActiveSummary(data);
      }
    } catch (err) {
      console.error('Error fetching summary for range:', err);
    } finally {
      setIsFetching(false);
    }
  };

  const getSegmentColor = (cat: string) => {
    switch (cat) {
      case 'Deep Work':
        return '#2563eb'; // blue
      case 'Learning':
        return '#16a34a'; // emerald green
      case 'Distraction':
      case 'Entertainment':
        return '#dc2626'; // rose red
      case 'Communication':
        return '#9333ea'; // purple
      case 'Utility':
      case 'Admin':
        return '#0891b2'; // cyan
      default:
        return '#64748b'; // slate for unclassified / unknown
    }
  };

  const formatSec = (seconds: number = 0) => {
    if (seconds <= 0) return '0s';
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    if (mins > 0 && secs > 0) return `${mins}m ${secs}s`;
    if (mins > 0) return `${mins}m`;
    return `${secs}s`;
  };

  const formatClockTime = (timeStr?: string) => {
    if (!timeStr) return '';
    return timeStr.replace(/:\d{2}$/, ''); // show HH:MM
  };

  // Derive real calculations from actual data
  const deepWorkSec = activeSummary?.total_deep_work_s ?? 0;
  const distractionSec = activeSummary?.total_distraction_s ?? 0;
  const switches = activeSummary?.context_switches ?? 0;
  const totalSec = activeSummary?.total_telemetry_s ?? (deepWorkSec + distractionSec);

  // Evidence-based calculations
  const longestSession = useMemo(() => {
    if (activeSummary?.longest_session_s && activeSummary.longest_session_s > 0) {
      return {
        durationSec: activeSummary.longest_session_s,
        app: activeSummary.longest_session_app || 'Workspace',
      };
    }
    if (chunks.length > 0) {
      let maxS = 0;
      let app = '';
      chunks.forEach((c) => {
        if (c.duration_s > maxS) {
          maxS = Math.round(c.duration_s);
          app = c.anchor_app || '';
        }
      });
      return { durationSec: maxS, app };
    }
    return { durationSec: 0, app: '' };
  }, [activeSummary, chunks]);

  const avgSwitchIntervalSec = useMemo(() => {
    if (activeSummary?.avg_dwell_per_switch_s) {
      return activeSummary.avg_dwell_per_switch_s;
    }
    return switches > 0 ? Math.round(totalSec / switches) : totalSec;
  }, [activeSummary, switches, totalSec]);

  const topApp = useMemo(() => {
    if (activeSummary?.top_app_today) {
      return activeSummary.top_app_today;
    }
    const appMap: Record<string, number> = {};
    displayEvents.forEach((e) => {
      if (e.app_name) {
        const sec = Math.round((e.dwell_ms || 2000) / 1000);
        appMap[e.app_name] = (appMap[e.app_name] || 0) + sec;
      }
    });
    let topName = '';
    let maxDwell = 0;
    Object.entries(appMap).forEach(([name, dwell]) => {
      if (dwell > maxDwell) {
        maxDwell = dwell;
        topName = name;
      }
    });
    return topName ? { name: topName, dwell_s: maxDwell } : null;
  }, [activeSummary, displayEvents]);

  const deepWorkPct = totalSec > 0 ? Math.round((deepWorkSec / totalSec) * 100) : 0;
  const distractionPct = totalSec > 0 ? Math.round((distractionSec / totalSec) * 100) : 0;

  const workState = hasData
    ? activeSummary?.work_state || (distractionSec > deepWorkSec ? 'UNSETTLED' : 'PRODUCTIVE')
    : 'AWAITING ACTIVITY';

  // Evidence-grounded KPI subtitles
  const deepSub = hasData
    ? longestSession.durationSec > 0
      ? `Longest flow: ${formatSec(longestSession.durationSec)} in ${longestSession.app || 'workspace'}`
      : `— ${formatSec(deepWorkSec)} focused work & research`
    : 'No focus sessions recorded';

  const distSub = hasData
    ? distractionSec > 0
      ? `↓ ${distractionPct}% of recorded time (${formatSec(distractionSec)})`
      : '0s recorded distraction · High focus'
    : 'No distraction data';

  const switchSub = hasData
    ? switches > 0
      ? `Avg ${formatSec(avgSwitchIntervalSec)} between ${switches} switches`
      : '0 window transitions detected'
    : '0 transitions recorded';

  const workStateSub = hasData
    ? totalSec === 0
      ? 'Waiting for agent activity'
      : `${deepWorkPct}% deep focus ratio · Verified by telemetry`
    : 'Run Windows agent to record';

  // Compute 7-day focus vs distraction distinguishing untracked days from 0-dwell tracked days
  const weeklyDaysComputed = useMemo(() => {
    const days = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
    const map = new Map<string, { deep: number; dist: number; isTracked: boolean }>();
    days.forEach((d) => map.set(d, { deep: 0, dist: 0, isTracked: false }));

    displayEvents.forEach((ev) => {
      let dayName = 'Today';
      if (ev.recorded_at) {
        const dateObj = new Date(ev.recorded_at);
        if (!isNaN(dateObj.getTime())) {
          dayName = days[dateObj.getDay()];
        }
      } else if (ev.date) {
        const dateObj = new Date(ev.date);
        if (!isNaN(dateObj.getTime())) {
          dayName = days[dateObj.getDay()];
        }
      }
      const entry = map.get(dayName) || { deep: 0, dist: 0, isTracked: false };
      entry.isTracked = true;
      const sec = Math.round((ev.dwell_ms || 2000) / 1000);
      if (ev.category === 'Deep Work' || ev.category === 'Learning') {
        entry.deep += Math.round(sec / 60);
      } else if (ev.category === 'Distraction' || ev.category === 'Entertainment') {
        entry.dist += Math.round(sec / 60);
      }
      map.set(dayName, entry);
    });

    const currentDayIdx = new Date().getDay();
    const orderedDays = [];
    for (let i = 6; i >= 0; i--) {
      const idx = (currentDayIdx - i + 7) % 7;
      const d = days[idx];
      const val = map.get(d) || { deep: 0, dist: 0, isTracked: false };
      orderedDays.push({
        day: d,
        deep: val.deep,
        dist: val.dist,
        isTracked: val.isTracked,
        isToday: i === 0,
      });
    }
    return orderedDays;
  }, [displayEvents]);

  const trackedDaysCount = weeklyDaysComputed.filter((d) => d.isTracked).length;

  // Compute 7x24 heatmap from real event hours
  const heatmapComputed = useMemo(() => {
    const grid: number[][] = Array.from({ length: 7 }, () => Array(24).fill(0));
    if (displayEvents.length === 0) return grid;

    displayEvents.forEach((ev) => {
      let h = 12;
      let d = 0;
      if (ev.recorded_at) {
        const dObj = new Date(ev.recorded_at);
        if (!isNaN(dObj.getTime())) {
          h = dObj.getHours();
          d = dObj.getDay();
        }
      } else if (ev.timestamp) {
        const parts = ev.timestamp.split(':');
        if (parts.length >= 1) {
          const parsedH = parseInt(parts[0], 10);
          if (!isNaN(parsedH)) h = parsedH % 24;
        }
      }
      const isDeep = ev.category === 'Deep Work' || ev.category === 'Learning';
      const weight = isDeep ? 0.35 : 0.15;
      grid[d % 7][h % 24] = Math.min(1, grid[d % 7][h % 24] + weight);
    });
    return grid;
  }, [displayEvents]);

  // Readable timeline scale calculation
  const timelineScale = useMemo(() => {
    if (displayEvents.length === 0) return null;
    const first = displayEvents[0].timestamp || '00:00';
    const last = displayEvents[displayEvents.length - 1].timestamp || '23:59';
    return {
      start: formatClockTime(first),
      end: formatClockTime(last),
      count: displayEvents.length,
    };
  }, [displayEvents]);

  return (
    <div className="space-y-4 pb-12 font-sans text-slate-800">
      {/* ─── DEVICE CONNECTION & AUDIT STATUS BANNER ─── */}
      <div
        className={`p-4 rounded-xl border transition-all shadow-2xs ${
          isDeviceConnected
            ? hasIncomingEvents
              ? 'border-emerald-200 bg-emerald-50/40'
              : 'border-emerald-200 bg-emerald-50/20'
            : hasData
            ? 'border-slate-200 bg-slate-50/70'
            : 'border-slate-200 bg-white'
        }`}
      >
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3.5">
          <div className="flex items-start sm:items-center gap-3">
            <div
              className={`w-9 h-9 rounded-lg flex items-center justify-center shrink-0 ${
                isDeviceConnected
                  ? 'bg-emerald-600 text-white'
                  : hasData
                  ? 'bg-slate-200 text-slate-700'
                  : 'bg-blue-50 text-blue-600 border border-blue-200'
              }`}
            >
              <Laptop className="w-4 h-4 stroke-[2]" />
            </div>

            <div>
              <div className="flex items-center gap-2 flex-wrap">
                <span className="text-xs font-semibold text-slate-900">
                  {device?.deviceName || 'Windows Workstation'}
                </span>
                <span className="text-slate-300" aria-hidden="true">·</span>

                {/* Honest Connection Status Text */}
                {isDeviceConnected ? (
                  <span className="text-xs text-emerald-800 font-medium flex items-center gap-1.5">
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-600 animate-pulse" />
                    Live streaming active
                  </span>
                ) : hasData ? (
                  <span className="text-xs text-slate-600 font-medium flex items-center gap-1.5">
                    <span className="w-1.5 h-1.5 rounded-full bg-slate-400" />
                    Showing historical activity (Device offline)
                  </span>
                ) : (
                  <span className="text-xs text-slate-500 font-medium flex items-center gap-1.5">
                    <span className="w-1.5 h-1.5 rounded-full bg-slate-300" />
                    Collector not connected
                  </span>
                )}

                {device?.lastEventTime && (
                  <>
                    <span className="text-slate-300" aria-hidden="true">·</span>
                    <span className="text-xs text-slate-500 font-mono tabular-nums">
                      Last event: {device.lastEventTime}
                    </span>
                  </>
                )}
              </div>

              {/* Status Explanation */}
              <p className="text-xs text-slate-500 mt-0.5 leading-relaxed">
                {isDeviceConnected
                  ? `Sampling active foreground window transitions at ${device?.samplingInterval || '500ms'} interval. No keystroke characters or screenshots collected.`
                  : hasData
                  ? `Historical telemetry preserved for auditing. Last verified connection: ${device?.lastSuccessfulConnectionAt ? new Date(device.lastSuccessfulConnectionAt).toLocaleTimeString() : 'Earlier today'}.`
                  : 'Connect your Windows workstation using the local Python agent to stream foreground activity securely.'}
              </p>
            </div>
          </div>

          {/* Action button */}
          <button
            type="button"
            onClick={onOpenDeviceModal}
            className={`inline-flex items-center justify-center gap-1.5 px-3.5 py-1.5 rounded-lg text-xs font-medium shadow-2xs transition-colors cursor-pointer shrink-0 ${
              isDeviceConnected
                ? 'bg-white hover:bg-slate-50 text-slate-700 border border-slate-300'
                : 'bg-slate-900 hover:bg-slate-800 text-white'
            }`}
          >
            <Laptop className="w-3.5 h-3.5" />
            <span>{isDeviceConnected ? 'Device Settings' : 'Connect Workstation'}</span>
          </button>
        </div>
      </div>

      {/* ─── SECTION HEADER & DATE RANGE FILTER ─── */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pt-1">
        <div>
          <h1 className="text-xl font-bold tracking-tight text-slate-900 leading-none">
            Activity &amp; Focus Overview
          </h1>
          <p className="text-xs text-slate-500 mt-1">
            Grounded cognitive timeline, intent breakdown, and micro-behavior patterns
          </p>
        </div>

        {/* Date Range Picker */}
        <div className="flex items-center gap-2">
          <DateRangePicker
            value={dateRange}
            onChange={handleDateRangeChange}
            isLoading={isFetching}
          />
        </div>
      </div>

      {/* ─── 1. TOP STAT ROW (GRID 4) ─── */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3.5">
        {/* Card 1: Sustained Deep Work */}
        <div className={`bg-white border border-slate-200 rounded-xl p-4 shadow-2xs transition-opacity duration-200 ${isFetching ? 'opacity-60' : 'opacity-100'}`}>
          <div className="text-xs text-slate-500 font-medium">Sustained Deep Work</div>
          <div className="text-2xl font-bold text-blue-600 mt-1 tracking-tight font-mono tabular-nums">
            {hasData ? formatSec(deepWorkSec) : '0s'}
          </div>
          <div className="text-xs text-slate-500 mt-1.5 font-normal truncate" title={deepSub}>
            {deepSub}
          </div>
        </div>

        {/* Card 2: Distraction Time */}
        <div className={`bg-white border border-slate-200 rounded-xl p-4 shadow-2xs transition-opacity duration-200 ${isFetching ? 'opacity-60' : 'opacity-100'}`}>
          <div className="text-xs text-slate-500 font-medium">Distraction Time</div>
          <div className="text-2xl font-bold text-rose-600 mt-1 tracking-tight font-mono tabular-nums">
            {hasData ? formatSec(distractionSec) : '0s'}
          </div>
          <div className="text-xs text-slate-500 mt-1.5 font-normal truncate" title={distSub}>
            {distSub}
          </div>
        </div>

        {/* Card 3: Context Switches */}
        <div className={`bg-white border border-slate-200 rounded-xl p-4 shadow-2xs transition-opacity duration-200 ${isFetching ? 'opacity-60' : 'opacity-100'}`}>
          <div className="text-xs text-slate-500 font-medium">Context Switches</div>
          <div className="text-2xl font-bold text-slate-900 mt-1 tracking-tight font-mono tabular-nums">
            {hasData ? switches : '0'}
          </div>
          <div className="text-xs text-slate-500 mt-1.5 font-normal truncate" title={switchSub}>
            {switchSub}
          </div>
        </div>

        {/* Card 4: Work State */}
        <div className={`bg-white border border-slate-200 rounded-xl p-4 shadow-2xs transition-opacity duration-200 ${isFetching ? 'opacity-60' : 'opacity-100'}`}>
          <div className="text-xs text-slate-500 font-medium">Work State</div>
          <div className={`text-xl font-bold mt-1.5 tracking-tight uppercase ${
            workState === 'PRODUCTIVE'
              ? 'text-emerald-700'
              : workState === 'AWAITING ACTIVITY'
              ? 'text-slate-400'
              : 'text-amber-700'
          }`}>
            {workState}
          </div>
          <div className="text-xs text-slate-500 mt-1.5 font-normal truncate" title={workStateSub}>
            {workStateSub}
          </div>
        </div>
      </div>

      {/* ─── COMPACT “YOUR DAY AT A GLANCE” INSIGHT SECTION ─── */}
      <div className="bg-slate-50/80 border border-slate-200 rounded-xl p-4 shadow-2xs">
        <div className="flex items-center justify-between pb-2.5 mb-2.5 border-b border-slate-200/60">
          <div className="flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-blue-600" />
            <h2 className="text-xs font-semibold text-slate-900 uppercase tracking-wider">
              Your Day at a Glance
            </h2>
          </div>
          <span className="text-[11px] text-slate-500 font-normal">
            Derived directly from {displayEvents.length} recorded window transitions
          </span>
        </div>

        {displayEvents.length === 0 ? (
          <div className="py-3 text-center text-xs text-slate-500">
            No telemetry stream recorded for this date. Run the Windows agent to populate verified focus insights.
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 text-xs">
            {/* Insight 1: Primary Application */}
            <div className="bg-white p-3 rounded-lg border border-slate-200/80">
              <span className="text-slate-500 text-[11px] block">Primary Focus Application</span>
              <div className="font-semibold text-slate-900 mt-0.5 truncate text-sm">
                {topApp?.name || 'Workspace'}
              </div>
              <div className="text-[11px] text-slate-500 mt-1 font-mono tabular-nums">
                {topApp ? `${formatSec(topApp.dwell_s)} dwell (${Math.round((topApp.dwell_s / (totalDwell / 1000 || 1)) * 100)}% of tracked time)` : 'None recorded'}
              </div>
            </div>

            {/* Insight 2: Longest Uninterrupted Flow */}
            <div className="bg-white p-3 rounded-lg border border-slate-200/80">
              <span className="text-slate-500 text-[11px] block">Longest Uninterrupted Session</span>
              <div className="font-semibold text-slate-900 mt-0.5 text-sm font-mono tabular-nums">
                {longestSession.durationSec > 0 ? formatSec(longestSession.durationSec) : '0s'}
              </div>
              <div className="text-[11px] text-slate-500 mt-1 truncate">
                {longestSession.app ? `In ${longestSession.app} without switching` : 'Awaiting extended focus block'}
              </div>
            </div>

            {/* Insight 3: Switch Interval Pacing */}
            <div className="bg-white p-3 rounded-lg border border-slate-200/80">
              <span className="text-slate-500 text-[11px] block">Switch Pacing &amp; Jitter</span>
              <div className="font-semibold text-slate-900 mt-0.5 text-sm font-mono tabular-nums">
                {switches > 0 ? `${formatSec(avgSwitchIntervalSec)} / switch` : 'Zero switches'}
              </div>
              <div className="text-[11px] text-slate-500 mt-1">
                {switches <= 5
                  ? 'High flow stability (low fragmentation)'
                  : switches <= 20
                  ? 'Balanced context switching rhythm'
                  : 'High frequency window transitions'}
              </div>
            </div>

            {/* Insight 4: Distraction Audit */}
            <div className="bg-white p-3 rounded-lg border border-slate-200/80">
              <span className="text-slate-500 text-[11px] block">Distraction Audit</span>
              <div className={`font-semibold mt-0.5 text-sm ${distractionSec === 0 ? 'text-emerald-700' : 'text-rose-700'}`}>
                {distractionSec === 0 ? '0s recorded' : formatSec(distractionSec)}
              </div>
              <div className="text-[11px] text-slate-500 mt-1 truncate" title={activeSummary?.distraction_triggers?.[0] || 'Clean stream'}>
                {distractionSec === 0
                  ? 'No distraction triggers observed'
                  : `Top trigger: ${activeSummary?.distraction_triggers?.[0] || 'Media dwell'}`}
              </div>
            </div>
          </div>
        )}
      </div>

      {/* ─── 2. ROW 2: TIMELINE + DONUT (GRID 2:1) ─── */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Left (2 spans): Today's Activity Timeline + Hourly Focus Heatmap */}
        <div className="lg:col-span-2 bg-white border border-slate-200 rounded-xl p-5 shadow-2xs flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-2">
              <div>
                <h2 className="text-sm font-semibold text-slate-900">Activity Timeline Strip</h2>
                <p className="text-[11px] text-slate-500">
                  Widths represent proportional dwell time. Click any segment to inspect details.
                </p>
              </div>
              {timelineScale && (
                <span className="text-xs text-slate-600 font-mono tabular-nums">
                  {timelineScale.start} → {timelineScale.end}
                </span>
              )}
            </div>

            {/* Segmented Timeline Bar with proportional widths */}
            <div className="relative mt-3">
              {displayEvents.length === 0 ? (
                <div className="h-12 w-full rounded-lg bg-slate-50 border border-dashed border-slate-200 flex flex-col items-center justify-center text-xs text-slate-400 gap-1">
                  <span>No live activity stream recorded for this date.</span>
                  <span className="text-[11px] text-slate-400">Click &quot;Connect Workstation&quot; to begin capturing events.</span>
                </div>
              ) : (
                <>
                  <div className="h-10 w-full rounded-lg overflow-hidden flex bg-slate-100 p-0.5 gap-[1px]">
                    {displayEvents.map((evt, idx) => {
                      const dwell = evt.dwell_ms || 2000;
                      const pct = totalDwell > 0 ? (dwell / totalDwell) * 100 : 100 / displayEvents.length;
                      const bg = getSegmentColor(evt.category);
                      const dwellSec = Math.round(dwell / 1000);
                      const isSelected = selectedTimelineItem?.timestamp === evt.timestamp && selectedTimelineItem?.window_title === evt.window_title;

                      return (
                        <div
                          key={idx}
                          onClick={() => {
                            setSelectedTimelineItem({
                              app_name: evt.app_name,
                              window_title: evt.window_title,
                              category: evt.category || 'Unclassified',
                              dwell_ms: dwell,
                              timestamp: evt.timestamp,
                              date: evt.date,
                            });
                          }}
                          onMouseEnter={() =>
                            setHoveredEvent(
                              `${evt.app_name}: ${evt.window_title} (${dwellSec}s · ${evt.timestamp})`
                            )
                          }
                          onMouseLeave={() => setHoveredEvent(null)}
                          style={{
                            width: `${Math.max(pct, 0.75)}%`,
                            backgroundColor: bg,
                          }}
                          className={`h-full rounded-[2px] cursor-pointer transition-all hover:brightness-110 ${
                            isSelected ? 'ring-2 ring-slate-900 z-10' : ''
                          }`}
                          title={`${evt.app_name}: ${evt.window_title} (${dwellSec}s · ${evt.timestamp})`}
                        />
                      );
                    })}
                  </div>

                  {/* Readable Clock Time Scale */}
                  {timelineScale && (
                    <div className="flex justify-between text-[10px] text-slate-500 font-mono tabular-nums mt-1.5 px-1">
                      <span>{timelineScale.start}</span>
                      <span>Midpoint</span>
                      <span>{timelineScale.end}</span>
                    </div>
                  )}
                </>
              )}

              {/* Hover tooltip */}
              {hoveredEvent && (
                <div className="absolute -top-8 left-2 bg-slate-900 text-white text-[11px] px-2.5 py-1 rounded shadow-md z-20 pointer-events-none truncate max-w-lg">
                  {hoveredEvent}
                </div>
              )}
            </div>

            {/* Clicked Timeline Item Inspector */}
            {selectedTimelineItem && (
              <div className="mt-3.5 p-3.5 rounded-lg bg-slate-50 border border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs animate-in fade-in duration-150">
                <div className="space-y-1">
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="font-semibold text-slate-900 text-sm">
                      {selectedTimelineItem.app_name}
                    </span>
                    <span className="text-slate-300" aria-hidden="true">·</span>
                    <span
                      className="inline-block w-2.5 h-2.5 rounded-[2px]"
                      style={{ backgroundColor: getSegmentColor(selectedTimelineItem.category) }}
                    />
                    <span className="font-medium text-slate-700">
                      {selectedTimelineItem.category}
                    </span>
                    <span className="text-slate-300" aria-hidden="true">·</span>
                    <span className="font-mono tabular-nums text-slate-600">
                      {formatSec(Math.round(selectedTimelineItem.dwell_ms / 1000))} dwell
                    </span>
                    <span className="text-slate-300" aria-hidden="true">·</span>
                    <span className="font-mono tabular-nums text-slate-500">
                      Recorded at {selectedTimelineItem.timestamp}
                    </span>
                  </div>
                  <div className="text-slate-600 truncate max-w-2xl font-mono text-[11px]">
                    {selectedTimelineItem.window_title}
                  </div>
                </div>

                <div className="flex items-center gap-2 shrink-0">
                  {onNavigateToTimeline && (
                    <button
                      onClick={onNavigateToTimeline}
                      className="text-xs text-blue-600 hover:text-blue-700 font-medium px-2.5 py-1 rounded border border-blue-200 bg-white hover:bg-blue-50 transition-colors cursor-pointer"
                    >
                      View in Timeline
                    </button>
                  )}
                  <button
                    onClick={() => setSelectedTimelineItem(null)}
                    className="text-slate-400 hover:text-slate-600 p-1 cursor-pointer"
                    title="Close inspector"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>
              </div>
            )}

            {/* Legend */}
            <div className="flex flex-wrap items-center gap-3.5 mt-3 text-xs text-slate-600">
              <div className="flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded-[2px] bg-[#2563eb]" />
                <span>Deep Work</span>
              </div>
              <div className="flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded-[2px] bg-[#16a34a]" />
                <span>Learning</span>
              </div>
              <div className="flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded-[2px] bg-[#dc2626]" />
                <span>Distraction</span>
              </div>
              <div className="flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded-[2px] bg-[#9333ea]" />
                <span>Communication</span>
              </div>
              <div className="flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded-[2px] bg-[#0891b2]" />
                <span>Utility</span>
              </div>
              <div className="flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded-[2px] bg-[#64748b]" />
                <span>Unclassified</span>
              </div>
            </div>
          </div>

          {/* Hourly Focus Heatmap */}
          <div className="mt-5 pt-4 border-t border-slate-100">
            <div className="flex items-center justify-between mb-2">
              <h3 className="text-xs font-semibold text-slate-900">
                Hourly Focus Heatmap (7 Days × 24 Hours)
              </h3>
              <span className="text-[11px] text-slate-500">
                Lighter = Low activity · Darker blue = Sustained focus
              </span>
            </div>

            {displayEvents.length === 0 ? (
              <div className="py-6 text-center text-xs text-slate-400 bg-slate-50/50 rounded-lg border border-dashed border-slate-200">
                <span>No hourly activity recorded yet this week.</span>
              </div>
            ) : (
              <div className="space-y-1">
                {heatmapComputed.map((dayRow, rIdx) => (
                  <div key={rIdx} className="grid grid-cols-24 gap-[3px]">
                    {dayRow.map((val, cIdx) => {
                      const isZero = val === 0;
                      return (
                        <div
                          key={cIdx}
                          className="h-5 rounded-[2px] transition-colors"
                          style={{
                            backgroundColor: isZero
                              ? '#f1f5f9'
                              : `rgba(37, 99, 235, ${Math.min(val * 0.9 + 0.12, 1)})`,
                          }}
                          title={`Day ${rIdx}, ${cIdx}:00: ${Math.round(val * 100)}% active focus density`}
                        />
                      );
                    })}
                  </div>
                ))}
              </div>
            )}

            <div className="flex justify-between text-[10px] text-slate-500 font-mono tabular-nums mt-1.5 px-0.5">
              <span>12 AM</span>
              <span>4 AM</span>
              <span>8 AM</span>
              <span>12 PM</span>
              <span>4 PM</span>
              <span>8 PM</span>
              <span>11 PM</span>
            </div>
          </div>
        </div>

        {/* Right (1 span): Session Intent Breakdown Donut + Micro-Behavior Patterns */}
        <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-2xs flex flex-col justify-between">
          <div>
            <div className="text-xs font-semibold uppercase tracking-wider text-slate-500 mb-2">
              Session Intent Breakdown
            </div>

            {/* SVG Donut Chart */}
            {(() => {
              if (displayEvents.length === 0) {
                return (
                  <div className="py-12 text-center text-xs text-slate-400">
                    <Compass className="w-8 h-8 text-slate-300 mx-auto mb-2" />
                    <span>0 focus sessions recorded</span>
                  </div>
                );
              }

              let deepSec = 0;
              let learnSec = 0;
              let distSec = 0;
              let utilitySec = 0;
              let commSec = 0;
              let unclassifiedSec = 0;

              displayEvents.forEach((e) => {
                const sec = Math.max(1, Math.round((e.dwell_ms || 2000) / 1000));
                const cat = e.category || 'Unclassified';
                if (cat === 'Deep Work') deepSec += sec;
                else if (cat === 'Learning') learnSec += sec;
                else if (cat === 'Distraction' || cat === 'Entertainment') distSec += sec;
                else if (cat === 'Communication') commSec += sec;
                else if (cat === 'Utility' || cat === 'Admin') utilitySec += sec;
                else unclassifiedSec += sec;
              });

              const total = deepSec + learnSec + distSec + utilitySec + commSec + unclassifiedSec || 1;
              const C = 213.63;
              const pDeep = deepSec / total;
              const pLearn = learnSec / total;
              const pDist = distSec / total;
              const pUtil = utilitySec / total;

              return (
                <div className="flex flex-col items-center justify-center my-2">
                  <div className="relative w-36 h-36">
                    <svg viewBox="0 0 100 100" className="w-full h-full -rotate-90">
                      {/* Deep Work */}
                      <circle
                        cx="50"
                        cy="50"
                        r="34"
                        fill="transparent"
                        stroke="#2563eb"
                        strokeWidth="16"
                        strokeDasharray={`${(pDeep * C).toFixed(1)} ${C.toFixed(1)}`}
                        strokeDashoffset="0"
                      />
                      {/* Learning */}
                      <circle
                        cx="50"
                        cy="50"
                        r="34"
                        fill="transparent"
                        stroke="#16a34a"
                        strokeWidth="16"
                        strokeDasharray={`${(pLearn * C).toFixed(1)} ${C.toFixed(1)}`}
                        strokeDashoffset={`${-(pDeep * C)}`}
                      />
                      {/* Distraction */}
                      <circle
                        cx="50"
                        cy="50"
                        r="34"
                        fill="transparent"
                        stroke="#dc2626"
                        strokeWidth="16"
                        strokeDasharray={`${(pDist * C).toFixed(1)} ${C.toFixed(1)}`}
                        strokeDashoffset={`${-((pDeep + pLearn) * C)}`}
                      />
                      {/* Utility */}
                      <circle
                        cx="50"
                        cy="50"
                        r="34"
                        fill="transparent"
                        stroke="#0891b2"
                        strokeWidth="16"
                        strokeDasharray={`${(pUtil * C).toFixed(1)} ${C.toFixed(1)}`}
                        strokeDashoffset={`${-((pDeep + pLearn + pDist) * C)}`}
                      />
                    </svg>
                    <div className="absolute inset-0 flex flex-col items-center justify-center text-center">
                      <span className="text-xl font-bold text-slate-900 font-mono tabular-nums">
                        {Math.round((deepSec / total) * 100)}%
                      </span>
                      <span className="text-[10px] text-slate-500 font-medium">Deep Focus</span>
                    </div>
                  </div>
                </div>
              );
            })()}
          </div>

          {/* Micro-Behavior Patterns from Live Session Data */}
          <div className="mt-4 pt-4 border-t border-slate-100">
            <div className="text-xs font-semibold uppercase tracking-wider text-slate-500 mb-3">
              Micro-Behavior Patterns
            </div>

            {(() => {
              const rapidSwitches = activeSummary?.context_switches ?? Math.max(0, displayEvents.length - 1);
              const tabFlickers = displayEvents.filter((e) => (e.dwell_ms || 2000) <= 3000).length;
              const avgDwellSec = displayEvents.length > 0 ? (totalDwell / displayEvents.length / 1000).toFixed(1) + 's' : '0s';

              return (
                <div className="space-y-2.5 text-xs">
                  <div className="flex items-center gap-2">
                    <span className="text-slate-600 w-24 shrink-0 text-xs">Rapid Switches</span>
                    <div className="flex-1 h-2 bg-slate-100 rounded-full overflow-hidden">
                      <div
                        className="h-full bg-blue-600 rounded-full transition-all"
                        style={{ width: `${Math.min(100, Math.max(rapidSwitches > 0 ? 8 : 0, rapidSwitches * 4))}%` }}
                      />
                    </div>
                    <span className="text-blue-600 font-semibold font-mono tabular-nums w-8 text-right text-xs">
                      {rapidSwitches}
                    </span>
                  </div>

                  <div className="flex items-center gap-2">
                    <span className="text-slate-600 w-24 shrink-0 text-xs">Tab Flickers</span>
                    <div className="flex-1 h-2 bg-slate-100 rounded-full overflow-hidden">
                      <div
                        className="h-full bg-amber-500 rounded-full transition-all"
                        style={{ width: `${Math.min(100, Math.max(tabFlickers > 0 ? 8 : 0, tabFlickers * 6))}%` }}
                      />
                    </div>
                    <span className="text-amber-600 font-semibold font-mono tabular-nums w-8 text-right text-xs">
                      {tabFlickers}
                    </span>
                  </div>

                  <div className="flex items-center gap-2">
                    <span className="text-slate-600 w-24 shrink-0 text-xs">Avg Micro Dwell</span>
                    <div className="flex-1 h-2 bg-slate-100 rounded-full overflow-hidden">
                      <div className="h-full bg-emerald-600 rounded-full w-[45%]" />
                    </div>
                    <span className="text-slate-700 font-semibold font-mono tabular-nums w-8 text-right text-xs">
                      {avgDwellSec}
                    </span>
                  </div>

                  <div className="flex items-center gap-2">
                    <span className="text-slate-600 w-24 shrink-0 text-xs">Active Sessions</span>
                    <div className="flex-1 h-2 bg-slate-100 rounded-full overflow-hidden">
                      <div
                        className="h-full bg-purple-600 rounded-full transition-all"
                        style={{ width: `${Math.min(100, Math.max(chunks.length > 0 ? 10 : 0, chunks.length * 10))}%` }}
                      />
                    </div>
                    <span className="text-purple-600 font-semibold font-mono tabular-nums w-8 text-right text-xs">
                      {chunks.length}
                    </span>
                  </div>
                </div>
              );
            })()}
          </div>
        </div>
      </div>

      {/* ─── 3. ROW 3: 7-DAY FOCUS VS DISTRACTION + DISTRACTION TRIGGERS (GRID 2) ─── */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* Left: 7-Day Focus vs Distraction Stacked Bar Chart with Untracked distinctions */}
        <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-2xs">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h2 className="text-xs font-semibold uppercase tracking-wider text-slate-500">
                7-Day Focus vs Distraction
              </h2>
              <p className="text-[11px] text-slate-400 mt-0.5">
                Distinguishes days with verified telemetry from untracked days
              </p>
            </div>
            <div className="flex items-center gap-3 text-xs text-slate-600">
              <div className="flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded-[2px] bg-blue-600" />
                <span>Deep Work</span>
              </div>
              <div className="flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded-[2px] bg-rose-500" />
                <span>Distraction</span>
              </div>
              <div className="flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded-[2px] bg-slate-200 border border-slate-300" />
                <span className="text-slate-400">Untracked</span>
              </div>
            </div>
          </div>

          {/* Stacked Bar Chart */}
          {displayEvents.length === 0 ? (
            <div className="h-52 flex flex-col items-center justify-center text-xs text-slate-400 bg-slate-50/50 rounded-lg border border-dashed border-slate-200">
              <span>No historical telemetry recorded for this 7-day period.</span>
              <span className="text-[11px] text-slate-400 mt-1">Connect your Windows device to record daily focus metrics.</span>
            </div>
          ) : (
            <div className="h-52 relative flex flex-col justify-between pt-2">
              {trackedDaysCount < 2 && (
                <div className="mb-2 text-[11px] text-slate-500 bg-slate-50 p-2 rounded-lg border border-slate-200 flex items-center gap-1.5">
                  <Info className="w-3.5 h-3.5 text-blue-600 shrink-0" />
                  <span>Only today&apos;s data recorded so far. Previous days will populate as the agent runs.</span>
                </div>
              )}

              <div className="relative h-36 ml-2 flex items-end justify-between px-3">
                {weeklyDaysComputed.map((item, idx) => {
                  const maxVal = Math.max(60, ...weeklyDaysComputed.map((d) => d.deep + d.dist));
                  const deepH = item.isTracked ? (item.deep / maxVal) * 100 : 0;
                  const distH = item.isTracked ? (item.dist / maxVal) * 100 : 0;

                  return (
                    <div key={idx} className="flex flex-col items-center w-9">
                      <div className="w-8 flex flex-col justify-end relative" style={{ height: '130px' }}>
                        {!item.isTracked ? (
                          <div
                            className="w-full h-8 rounded-t border border-dashed border-slate-300 bg-slate-100/60 flex items-center justify-center text-[9px] text-slate-400 font-mono"
                            title={`${item.day}: Untracked (No agent telemetry logged)`}
                          >
                            —
                          </div>
                        ) : (
                          <>
                            {item.dist > 0 && (
                              <div
                                style={{ height: `${Math.max(distH, 4)}%` }}
                                className="w-full bg-rose-500 rounded-t-[2px] transition-all"
                                title={`${item.day} Distraction: ${item.dist}m`}
                              />
                            )}
                            {item.deep > 0 && (
                              <div
                                style={{ height: `${Math.max(deepH, 6)}%` }}
                                className={`w-full bg-blue-600 transition-all ${
                                  item.dist === 0 ? 'rounded-t-[2px]' : ''
                                }`}
                                title={`${item.day} Deep Work: ${item.deep}m`}
                              />
                            )}
                            {item.deep === 0 && item.dist === 0 && (
                              <div
                                className="w-full h-2 rounded bg-slate-200"
                                title={`${item.day}: Tracked, 0m focus dwell`}
                              />
                            )}
                          </>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>

              {/* X-axis Labels */}
              <div className="ml-2 flex justify-between px-3 text-[11px] text-slate-500 pt-1.5 border-t border-slate-200">
                {weeklyDaysComputed.map((d, i) => (
                  <span
                    key={i}
                    className={`w-9 text-center font-medium ${
                      d.isToday ? 'text-blue-600 font-bold' : d.isTracked ? 'text-slate-700' : 'text-slate-400'
                    }`}
                  >
                    {d.day}
                  </span>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Right: Distraction Triggers */}
        <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-2xs">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h2 className="text-xs font-semibold uppercase tracking-wider text-slate-500">
                Distraction Triggers (By Dwell Time)
              </h2>
              <p className="text-[11px] text-slate-400 mt-0.5">
                Exact window titles that led to context breaks
              </p>
            </div>
          </div>

          <div className="space-y-4 pt-1">
            {(() => {
              const triggerMap = new Map<string, number>();
              displayEvents.forEach((e) => {
                if (e.category === 'Distraction' || e.category === 'Entertainment') {
                  const title = e.window_title || e.app_name || 'Media';
                  triggerMap.set(title, (triggerMap.get(title) || 0) + Math.round((e.dwell_ms || 2000) / 1000));
                }
              });
              const triggers = Array.from(triggerMap.entries()).sort((a, b) => b[1] - a[1]).slice(0, 5);

              if (triggers.length === 0) {
                return (
                  <div className="py-12 text-center text-xs text-slate-500">
                    <p className="font-semibold text-emerald-700">0s recorded distraction</p>
                    <p className="text-[11px] text-slate-400 mt-1">
                      {hasData
                        ? 'High focus sustained across your active desktop applications.'
                        : 'No distraction micro-events recorded yet.'}
                    </p>
                  </div>
                );
              }

              const maxDwell = triggers[0][1] || 1;
              const barColors = ['bg-rose-600', 'bg-amber-600', 'bg-purple-600', 'bg-rose-500', 'bg-blue-600'];

              return triggers.map(([name, dwellSec], idx) => (
                <div key={idx} className="flex items-center gap-3 text-xs">
                  <span className="w-48 text-slate-700 truncate font-medium" title={name}>
                    {name}
                  </span>
                  <div className="flex-1 h-2 bg-slate-100 rounded-full overflow-hidden">
                    <div
                      className={`h-full ${barColors[idx % barColors.length]} rounded-full transition-all`}
                      style={{ width: `${Math.min(100, Math.max(10, Math.round((dwellSec / maxDwell) * 100)))}%` }}
                    />
                  </div>
                  <span className="w-14 text-right text-slate-500 font-mono text-[11px] tabular-nums">
                    {dwellSec}s
                  </span>
                </div>
              ));
            })()}
          </div>
        </div>
      </div>
    </div>
  );
};
