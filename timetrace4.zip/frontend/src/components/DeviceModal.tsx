import React, { useState, useEffect } from 'react';
import {
  Laptop,
  CheckCircle2,
  X,
  RefreshCw,
  Copy,
  Check,
  Download,
  AlertCircle,
  Shield,
  XCircle,
  Radio,
  FileCode,
  ClipboardPaste,
  ChevronDown,
  ChevronUp,
  Key,
  Pause,
  Play,
  HelpCircle,
  Terminal,
} from 'lucide-react';
import { DeviceState } from '@shared/types/chronotrace';
import { apiFetch } from '../lib/api';

interface DeviceModalProps {
  device: DeviceState | null;
  onClose: () => void;
  onRefresh: () => void;
  userToken?: string;
  liveFileActive?: boolean;
  onSetLiveFileHandle?: (handle: any) => void;
  onStopLiveStream?: () => void;
  onTokenRegenerated?: (newToken: string) => void;
}

const formatDateTime = (iso?: string | null) => {
  if (!iso) return 'Never';
  try {
    const d = new Date(iso);
    return isNaN(d.getTime())
      ? 'Never'
      : d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }) +
          ', ' +
          d.toLocaleDateString();
  } catch {
    return 'Never';
  }
};

const formatRelativeTime = (iso?: string | null) => {
  if (!iso) return 'Never';
  try {
    const ms = Date.parse(iso);
    if (isNaN(ms)) return 'Never';
    const diffSec = Math.max(0, Math.round((Date.now() - ms) / 1000));
    if (diffSec < 5) return 'Just now';
    if (diffSec < 60) return `${diffSec}s ago`;
    const min = Math.floor(diffSec / 60);
    return `${min}m ago`;
  } catch {
    return 'Never';
  }
};

export const DeviceModal: React.FC<DeviceModalProps> = ({
  device,
  onClose,
  onRefresh,
  userToken: initialUserToken,
  liveFileActive = false,
  onSetLiveFileHandle,
  onStopLiveStream,
  onTokenRegenerated,
}) => {
  const [currentToken, setCurrentToken] = useState<string>(initialUserToken || '');
  const [testing, setTesting] = useState(false);
  const [copiedManual, setCopiedManual] = useState(false);
  const [copiedClipCmd, setCopiedClipCmd] = useState(false);
  const [copiedToken, setCopiedToken] = useState(false);
  const [isRegeneratingToken, setIsRegeneratingToken] = useState(false);
  const [message, setMessage] = useState<{ text: string; success: boolean } | null>(null);
  const [syncingFile, setSyncingFile] = useState(false);
  const [showAdvanced, setShowAdvanced] = useState(false);
  const [showTroubleshooting, setShowTroubleshooting] = useState(false);
  const [isTogglingPause, setIsTogglingPause] = useState(false);

  useEffect(() => {
    if (initialUserToken) {
      setCurrentToken(initialUserToken);
    }
  }, [initialUserToken]);

  // Auto-refresh status while modal is open
  useEffect(() => {
    const interval = setInterval(() => {
      onRefresh();
    }, 2000);

    return () => clearInterval(interval);
  }, [onRefresh]);

  const isConnected = device?.status === 'CONNECTED' || device?.status === 'CONNECTED_AWAITING_ACTIVITY';
  const isReconnecting = device?.status === 'RECONNECTING';
  const isPaused = device?.paused === true;

  const handleDownload = async (e: React.MouseEvent) => {
    e.preventDefault();
    const tokenParam = currentToken ? `?token=${encodeURIComponent(currentToken)}` : '';
    try {
      const res = await apiFetch(`/api/download-agent${tokenParam}`);
      if (!res.ok) throw new Error('Download failed');
      const text = await res.text();
      if (text.trim().startsWith('{') && text.includes('"error"')) {
        throw new Error('Server returned error');
      }
      const blob = new Blob([text], { type: 'text/x-python;charset=utf-8' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = 'chronotrace_agent.py';
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      setTimeout(() => URL.revokeObjectURL(url), 1500);
      setMessage({
        text: 'Agent downloaded! Follow Step 2 below to run it in PowerShell.',
        success: true,
      });
    } catch {
      // Iframe-safe download fallback without window navigation
      const a = document.createElement('a');
      a.href = `/api/download-agent${tokenParam}`;
      a.setAttribute('download', 'chronotrace_agent.py');
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
    }
  };

  const copyManual = () => {
    const cmd = `cd "$env:USERPROFILE\\Downloads"; python chronotrace_agent.py`;
    navigator.clipboard.writeText(cmd);
    setCopiedManual(true);
    setTimeout(() => setCopiedManual(false), 2000);
  };

  const copyToken = () => {
    if (!currentToken) return;
    navigator.clipboard.writeText(currentToken);
    setCopiedToken(true);
    setTimeout(() => setCopiedToken(false), 2000);
  };

  const [confirmRegenerate, setConfirmRegenerate] = useState(false);

  const handleRegenerateToken = async () => {
    if (!confirmRegenerate) {
      setConfirmRegenerate(true);
      return;
    }
    setConfirmRegenerate(false);
    setIsRegeneratingToken(true);
    setMessage(null);
    try {
      const res = await apiFetch('/api/device/regenerate-token', { method: 'POST' });
      const data = await res.json();
      if (res.ok && data.success && data.deviceToken) {
        setCurrentToken(data.deviceToken);
        if (onTokenRegenerated) onTokenRegenerated(data.deviceToken);
        onRefresh();
        setMessage({
          text: 'New device credential generated. Previous credential was revoked.',
          success: true,
        });
      } else {
        throw new Error(data.error || 'Failed to regenerate token');
      }
    } catch (e: any) {
      setMessage({ text: e.message || 'Error regenerating token', success: false });
    } finally {
      setIsRegeneratingToken(false);
    }
  };

  const handleTogglePause = async () => {
    setIsTogglingPause(true);
    try {
      const targetState = isPaused ? true : false; // toggle
      const res = await apiFetch('/api/device/toggle', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ connected: targetState }),
      });
      if (res.ok) {
        onRefresh();
        setMessage({
          text: targetState ? 'Collection resumed.' : 'Collection paused on website.',
          success: true,
        });
      }
    } catch {
      // non-fatal
    } finally {
      setIsTogglingPause(false);
    }
  };

  const handleTestConnection = async () => {
    setTesting(true);
    setMessage(null);
    try {
      const res = await apiFetch('/api/device/status');
      const data = await res.json();
      onRefresh();
      if (data.connected) {
        setMessage({
          text: 'Verified! Heartbeats and live telemetry are reaching the backend.',
          success: true,
        });
      } else if (data.status === 'RECONNECTING') {
        setMessage({
          text: 'Agent is reconnecting. Keep your terminal open while network resumes.',
          success: false,
        });
      } else {
        setMessage({
          text: 'No active agent communication detected. Run the PowerShell command and keep the terminal window open.',
          success: false,
        });
      }
    } catch {
      setMessage({
        text: 'Could not contact server. Please check your network connection.',
        success: false,
      });
    } finally {
      setTesting(false);
    }
  };

  // Advanced Fallback Handlers
  const handleManualFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setSyncingFile(true);
    setMessage(null);
    try {
      const text = await file.text();
      const parsed = JSON.parse(text);
      const res = await apiFetch('/api/agent/sync-file', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          sessions: parsed.sessions || [],
          current: parsed.current,
          userToken: currentToken,
          deviceName: parsed.deviceName || 'Windows Workstation',
          os: parsed.os,
        }),
      });
      const data = await res.json();
      if (res.ok && data.success) {
        onRefresh();
        setMessage({
          text: `Synced ${data.syncedSessions || 0} activities from ${file.name}!`,
          success: true,
        });
      } else {
        throw new Error(data.error || 'Failed to sync activity file');
      }
    } catch (err: any) {
      setMessage({
        text: `Error reading file: ${err.message || 'Invalid JSON format'}`,
        success: false,
      });
    } finally {
      setSyncingFile(false);
      e.target.value = '';
    }
  };

  const handleClipboardSync = async () => {
    setMessage(null);
    try {
      const clipText = await navigator.clipboard.readText();
      if (!clipText || (!clipText.trim().startsWith('{') && !clipText.trim().startsWith('['))) {
        setMessage({
          text: 'Clipboard does not contain valid JSON. Run the copy command in PowerShell first.',
          success: false,
        });
        return;
      }
      const parsed = JSON.parse(clipText);
      const res = await apiFetch('/api/agent/sync-file', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          sessions: parsed.sessions || [],
          current: parsed.current,
          userToken: currentToken,
          deviceName: parsed.deviceName || 'Windows Workstation',
          os: parsed.os,
        }),
      });
      const data = await res.json();
      if (res.ok && data.success) {
        onRefresh();
        setMessage({
          text: `Synced ${data.syncedSessions || 0} activities from clipboard!`,
          success: true,
        });
      } else {
        throw new Error(data.error || 'Failed to sync clipboard data');
      }
    } catch (err: any) {
      setMessage({
        text: `Clipboard sync error: ${err.message || 'Could not access clipboard'}`,
        success: false,
      });
    }
  };

  const copyClipCmd = () => {
    navigator.clipboard.writeText('Get-Content ~/chronotrace_live.json -Raw | Set-Clipboard');
    setCopiedClipCmd(true);
    setTimeout(() => setCopiedClipCmd(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/50 backdrop-blur-xs p-4">
      <div className="bg-white border border-slate-200 rounded-2xl max-w-lg w-full p-6 shadow-2xl relative animate-in fade-in zoom-in-95 duration-150 max-h-[92vh] overflow-y-auto">
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-slate-100">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-blue-50 border border-blue-200 flex items-center justify-center text-blue-600">
              <Laptop className="w-4 h-4" />
            </div>
            <div>
              <h3 className="font-bold text-slate-900 text-sm">Windows Device Connection</h3>
              <p className="text-[11px] text-slate-500">Live passive laptop telemetry ingestion</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-slate-600 p-1.5 rounded-lg hover:bg-slate-100 transition-colors cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="space-y-4 my-4 text-xs">
          {/* Real-time Connection State & Live Heartbeat Card */}
          <div
            className={`p-4 rounded-xl border transition-colors ${
              isConnected
                ? 'bg-emerald-50/80 border-emerald-300'
                : isReconnecting
                ? 'bg-amber-50/80 border-amber-300'
                : isPaused
                ? 'bg-slate-100 border-slate-300'
                : 'bg-slate-50 border-slate-200'
            }`}
          >
            <div className="flex items-center justify-between">
              <div>
                <div className="font-bold text-slate-900 text-sm flex items-center gap-2">
                  <span>{device?.deviceName || 'Windows Workstation'}</span>
                  {isPaused && (
                    <span className="px-1.5 py-0.5 rounded text-[10px] font-medium bg-slate-200 text-slate-700">
                      Paused
                    </span>
                  )}
                </div>
                <div className="text-slate-500 text-[11px] mt-0.5">
                  {device?.os || 'Windows 10/11'} · Agent v{device?.agentVersion || '1.3.0'}
                </div>
              </div>

              {/* Status Badge */}
              <div>
                {isConnected ? (
                  <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-[11px] font-semibold bg-emerald-100 text-emerald-800 border border-emerald-300 shadow-2xs">
                    <span className="w-2 h-2 rounded-full bg-emerald-600 animate-pulse" />
                    {device?.status === 'CONNECTED'
                      ? 'Connected · Live Stream'
                      : 'Connected · Awaiting Activity'}
                  </span>
                ) : isReconnecting ? (
                  <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-[11px] font-semibold bg-amber-100 text-amber-800 border border-amber-300">
                    <span className="w-2 h-2 rounded-full bg-amber-600 animate-pulse" />
                    Reconnecting…
                  </span>
                ) : isPaused ? (
                  <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-[11px] font-semibold bg-slate-200 text-slate-700 border border-slate-300">
                    <Pause className="w-3 h-3 text-slate-500" />
                    Paused
                  </span>
                ) : device?.status === 'DISCONNECTED' ? (
                  <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[11px] font-semibold bg-amber-100 text-amber-800 border border-amber-300">
                    <AlertCircle className="w-3 h-3 text-amber-600" />
                    Disconnected · Offline
                  </span>
                ) : (
                  <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[11px] font-semibold bg-slate-200 text-slate-700 border border-slate-300">
                    <XCircle className="w-3 h-3 text-slate-500" />
                    Not Connected
                  </span>
                )}
              </div>
            </div>

            {/* Metrics Row: Last Heartbeat, Last Activity, Event Count */}
            <div className="grid grid-cols-3 gap-2 text-[11px] text-slate-600 pt-3 mt-3 border-t border-slate-200/80">
              <div className="bg-white/80 p-2 rounded-lg border border-slate-200/60">
                <span className="text-slate-400 block text-[10px]">Last Heartbeat</span>
                <strong className="font-semibold text-slate-800">
                  {formatRelativeTime(device?.lastHeartbeatAt)}
                </strong>
              </div>
              <div className="bg-white/80 p-2 rounded-lg border border-slate-200/60 truncate">
                <span className="text-slate-400 block text-[10px]">Last Activity</span>
                <strong className="font-semibold text-slate-800 truncate block" title={device?.currentWindowTitle || device?.lastEventTime || 'None'}>
                  {device?.currentForegroundApp
                    ? `${device.currentForegroundApp}`
                    : device?.lastEventTime || 'None yet'}
                </strong>
              </div>
              <div className="bg-white/80 p-2 rounded-lg border border-slate-200/60">
                <span className="text-slate-400 block text-[10px]">Events Today</span>
                <strong className="font-semibold text-slate-800">{device?.eventCount || 0}</strong>
              </div>
            </div>

            {/* Quick Pause / Resume Control */}
            <div className="flex items-center justify-between pt-2 text-[11px]">
              <span className="text-slate-500">
                {isPaused ? 'Telemetry paused. Click resume to ingest.' : 'Passively streaming live foreground switches.'}
              </span>
              <button
                type="button"
                onClick={handleTogglePause}
                disabled={isTogglingPause}
                className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-md text-[11px] font-medium transition-colors cursor-pointer border ${
                  isPaused
                    ? 'bg-emerald-600 hover:bg-emerald-700 text-white border-emerald-600'
                    : 'bg-white hover:bg-slate-100 text-slate-700 border-slate-300'
                }`}
              >
                {isPaused ? <Play className="w-3 h-3" /> : <Pause className="w-3 h-3" />}
                <span>{isPaused ? 'Resume Stream' : 'Pause'}</span>
              </button>
            </div>
          </div>

          {/* Feedback Message */}
          {message && (
            <div
              className={`p-3 rounded-xl border text-xs flex items-start gap-2 animate-in fade-in duration-200 ${
                message.success
                  ? 'bg-emerald-50 border-emerald-200 text-emerald-800'
                  : 'bg-amber-50 border-amber-200 text-amber-800'
              }`}
            >
              {message.success ? (
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
              ) : (
                <AlertCircle className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
              )}
              <span className="font-medium leading-relaxed">{message.text}</span>
            </div>
          )}

          {/* PRIMARY SETUP HERO ACTION: DOWNLOAD WINDOWS AGENT */}
          <div className="p-4 rounded-xl border-2 border-blue-500 bg-blue-50/50 shadow-xs space-y-3">
            <div className="flex items-center justify-between">
              <span className="font-bold text-slate-900 text-xs flex items-center gap-2">
                <Terminal className="w-4 h-4 text-blue-600" />
                Setup Windows Agent (Recommended)
              </span>
              <span className="text-[10px] font-semibold text-blue-700 bg-blue-100 border border-blue-200 px-2 py-0.5 rounded-full">
                Zero Pip Packages
              </span>
            </div>

            <p className="text-[11px] text-slate-600 leading-relaxed">
              Download the lightweight Python agent. It uses only Python standard library to read foreground window titles and streams authenticated events directly to this website via HTTPS.
            </p>

            <div className="space-y-2.5 pt-1">
              {/* Step 1: Download */}
              <div className="bg-white p-3 rounded-xl border border-slate-200 flex items-center justify-between gap-3 shadow-2xs">
                <div>
                  <div className="font-semibold text-slate-900 text-[11px]">
                    Step 1: Download Agent File
                  </div>
                  <div className="text-[10px] text-slate-500">
                    Pre-configured with your private device credential.
                  </div>
                </div>
                <button
                  type="button"
                  onClick={handleDownload}
                  className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg bg-blue-600 hover:bg-blue-700 text-white font-semibold transition-all cursor-pointer text-xs shrink-0 shadow-2xs"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>Download .py</span>
                </button>
              </div>

              {/* Step 2: Run Command */}
              <div className="bg-white p-3 rounded-xl border border-slate-200 space-y-1.5 shadow-2xs">
                <div className="flex items-center justify-between">
                  <div className="font-semibold text-slate-900 text-[11px]">
                    Step 2: Run in PowerShell or Command Prompt
                  </div>
                  <span className="text-[10px] text-slate-400">Keep terminal open</span>
                </div>
                <div className="relative group">
                  <div className="p-2.5 bg-slate-900 text-emerald-400 font-mono text-[10px] rounded-lg break-all select-all pr-16 leading-relaxed">
                    cd "$env:USERPROFILE\Downloads"; python chronotrace_agent.py
                  </div>
                  <button
                    type="button"
                    onClick={copyManual}
                    className="absolute right-1.5 top-1.5 inline-flex items-center gap-1 px-2.5 py-1 rounded bg-slate-800 hover:bg-slate-700 text-white text-[10px] font-medium transition-colors cursor-pointer border border-slate-700"
                  >
                    {copiedManual ? (
                      <>
                        <Check className="w-3 h-3 text-emerald-400" />
                        <span className="text-emerald-400">Copied</span>
                      </>
                    ) : (
                      <>
                        <Copy className="w-3 h-3" />
                        <span>Copy</span>
                      </>
                    )}
                  </button>
                </div>
              </div>

              {/* Step 3: Pairing Token & Revocation */}
              <div className="bg-white p-3 rounded-xl border border-slate-200 space-y-1.5 shadow-2xs">
                <div className="flex items-center justify-between">
                  <div className="font-semibold text-slate-900 text-[11px] flex items-center gap-1.5">
                    <Key className="w-3 h-3 text-slate-500" />
                    <span>Device Pairing Credential</span>
                  </div>
                  <button
                    type="button"
                    onClick={handleRegenerateToken}
                    disabled={isRegeneratingToken}
                    className={`text-[10px] font-medium cursor-pointer transition-colors ${
                      confirmRegenerate
                        ? 'text-rose-700 bg-rose-50 border border-rose-300 px-2 py-0.5 rounded font-semibold'
                        : 'text-rose-600 hover:text-rose-700 hover:underline'
                    }`}
                  >
                    {isRegeneratingToken
                      ? 'Revoking...'
                      : confirmRegenerate
                      ? 'Confirm Revocation?'
                      : 'Revoke & New Token'}
                  </button>
                </div>
                <div className="flex items-center gap-2">
                  <div className="flex-1 p-2 bg-slate-50 border border-slate-200 rounded-lg text-slate-700 font-mono text-[10px] truncate select-all">
                    {currentToken ? `${currentToken.slice(0, 10)}••••••••••••••••${currentToken.slice(-6)}` : 'No token assigned'}
                  </div>
                  <button
                    type="button"
                    onClick={copyToken}
                    className="px-2.5 py-1.5 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 text-[10px] font-medium transition-colors cursor-pointer shrink-0 border border-slate-300"
                  >
                    {copiedToken ? 'Copied' : 'Copy'}
                  </button>
                </div>
              </div>
            </div>
          </div>

          {/* Connection Troubleshooting Accordion */}
          <div className="border border-slate-200 rounded-xl overflow-hidden bg-white">
            <button
              type="button"
              onClick={() => setShowTroubleshooting(!showTroubleshooting)}
              className="w-full p-3 flex items-center justify-between text-left hover:bg-slate-50 transition-colors cursor-pointer text-xs font-semibold text-slate-800"
            >
              <div className="flex items-center gap-2">
                <HelpCircle className="w-3.5 h-3.5 text-blue-600" />
                <span>Connection Troubleshooting &amp; Setup Tips</span>
              </div>
              {showTroubleshooting ? <ChevronUp className="w-3.5 h-3.5 text-slate-400" /> : <ChevronDown className="w-3.5 h-3.5 text-slate-400" />}
            </button>

            {showTroubleshooting && (
              <div className="p-3.5 pt-1 space-y-2.5 border-t border-slate-100 text-[11px] text-slate-600">
                <div className="space-y-1">
                  <strong className="text-slate-800 block">1. &apos;python is not recognized&apos;</strong>
                  <p>
                    Download and install Python from <span className="font-mono text-blue-600">python.org</span> or Microsoft Store. During installation, make sure to check <em>&quot;Add Python to PATH&quot;</em>.
                  </p>
                </div>
                <div className="space-y-1">
                  <strong className="text-slate-800 block">2. PowerShell execution policy warning</strong>
                  <p>
                    If running scripts is restricted, run: <code className="p-1 bg-slate-100 rounded text-slate-800 font-mono">Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass</code>
                  </p>
                </div>
                <div className="space-y-1">
                  <strong className="text-slate-800 block">3. Network &amp; Proxy Resiliency</strong>
                  <p>
                    The agent includes an in-memory queue. If your laptop temporarily loses Wi-Fi, it queues events and automatically flushes them without duplicates once reconnected.
                  </p>
                </div>
              </div>
            )}
          </div>

          {/* Advanced / Offline Import Options (Moved to Collapsible per Requirement 1) */}
          <div className="border border-slate-200 rounded-xl overflow-hidden bg-slate-50">
            <button
              type="button"
              onClick={() => setShowAdvanced(!showAdvanced)}
              className="w-full p-3 flex items-center justify-between text-left hover:bg-slate-100 transition-colors cursor-pointer text-xs font-medium text-slate-600"
            >
              <div className="flex items-center gap-2">
                <FileCode className="w-3.5 h-3.5 text-slate-500" />
                <span>Advanced &amp; Offline Options (JSON &amp; Clipboard Sync)</span>
              </div>
              {showAdvanced ? <ChevronUp className="w-3.5 h-3.5 text-slate-400" /> : <ChevronDown className="w-3.5 h-3.5 text-slate-400" />}
            </button>

            {showAdvanced && (
              <div className="p-3.5 pt-1 space-y-3 border-t border-slate-200 bg-white text-[11px]">
                <p className="text-slate-500">
                  If your laptop is offline or in a restricted network, you can manually import session data:
                </p>

                {/* Import .json */}
                <div className="flex items-center justify-between p-2 rounded-lg bg-slate-50 border border-slate-200">
                  <div>
                    <strong className="text-slate-800 block text-[11px]">Import Saved JSON File</strong>
                    <span className="text-slate-500 text-[10px]">Loads from ~/chronotrace_live.json</span>
                  </div>
                  <label className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-white border border-slate-300 hover:bg-slate-50 text-slate-700 font-medium cursor-pointer text-xs shrink-0 shadow-2xs">
                    <FileCode className="w-3 h-3 text-blue-600" />
                    <span>{syncingFile ? 'Syncing...' : 'Select File'}</span>
                    <input
                      id="manual-json-file-input"
                      type="file"
                      accept=".json"
                      onChange={handleManualFileUpload}
                      disabled={syncingFile}
                      className="hidden"
                    />
                  </label>
                </div>

                {/* 1-Click Clipboard Sync */}
                <div className="p-2.5 rounded-lg bg-slate-50 border border-slate-200 space-y-2">
                  <div className="flex items-center justify-between">
                    <strong className="text-slate-800 text-[11px] flex items-center gap-1">
                      <ClipboardPaste className="w-3 h-3 text-slate-500" />
                      Clipboard Snapshot Sync
                    </strong>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <div className="flex-1 p-1.5 bg-slate-900 text-emerald-400 font-mono text-[9px] rounded truncate select-all">
                      Get-Content ~/chronotrace_live.json -Raw | Set-Clipboard
                    </div>
                    <button
                      type="button"
                      onClick={copyClipCmd}
                      className="px-2 py-1 rounded bg-slate-800 hover:bg-slate-700 text-white text-[10px] font-medium cursor-pointer shrink-0"
                    >
                      {copiedClipCmd ? 'Copied' : 'Copy Cmd'}
                    </button>
                    <button
                      type="button"
                      onClick={handleClipboardSync}
                      className="px-2.5 py-1 rounded bg-emerald-600 hover:bg-emerald-700 text-white text-[10px] font-semibold cursor-pointer shrink-0 shadow-2xs"
                    >
                      Paste &amp; Sync
                    </button>
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* Privacy Note (Requirement 9) */}
          <div className="p-3 rounded-xl bg-slate-50 border border-slate-200 flex items-start gap-2.5 text-[11px] text-slate-600 leading-relaxed">
            <Shield className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
            <div>
              <strong className="text-slate-800 block text-[11px]">Strict Privacy Guarantee</strong>
              <span>
                ChronoTrace collects only the foreground application name and active window title for cognitive reconstruction. No keystroke logging, no screen captures, no webcam/audio, and no background process inspection.
              </span>
            </div>
          </div>
        </div>

        {/* Footer Actions */}
        <div className="flex items-center justify-between pt-3 border-t border-slate-100">
          <button
            type="button"
            onClick={handleTestConnection}
            disabled={testing}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-semibold bg-blue-600 hover:bg-blue-700 text-white transition-colors cursor-pointer disabled:opacity-60 shadow-xs"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${testing ? 'animate-spin' : ''}`} />
            <span>{testing ? 'Verifying...' : 'Check Connection'}</span>
          </button>

          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 rounded-xl text-xs font-medium text-slate-600 hover:bg-slate-100 transition-colors cursor-pointer"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
