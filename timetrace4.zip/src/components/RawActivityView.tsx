import React, { useState, useMemo } from 'react';
import {
  Search,
  Filter,
  Download,
  ChevronLeft,
  ChevronRight,
  Shield,
  Eye,
  X,
  FileSpreadsheet,
  HelpCircle,
  Database,
  Terminal,
  CornerDownRight,
  Info,
} from 'lucide-react';
import { TelemetryEvent } from '@shared/types/chronotrace';

interface RawActivityViewProps {
  events: TelemetryEvent[];
  onOpenDeviceModal?: () => void;
}

export const RawActivityView: React.FC<RawActivityViewProps> = ({
  events,
  onOpenDeviceModal,
}) => {
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [categoryFilter, setCategoryFilter] = useState<string>('ALL');
  const [sortOrder, setSortOrder] = useState<'newest' | 'oldest'>('newest');
  const [currentPage, setCurrentPage] = useState<number>(1);
  const [pageSize] = useState<number>(20);
  const [selectedEvent, setSelectedEvent] = useState<TelemetryEvent | null>(null);

  // Filter out obsolete dummy seed entries when real device activities are captured
  const liveEvents = useMemo(() => {
    if (!events || events.length === 0) return [];
    return events.filter(
      (e) =>
        !e.id?.includes('seed-') &&
        !e.id?.includes('dummy') &&
        e.timestamp !== '18:52:14' &&
        !e.window_title?.includes('Switch Case - YouTube')
    );
  }, [events]);

  // Extract categories dynamically
  const categories = useMemo(() => {
    const set = new Set<string>();
    liveEvents.forEach((e) => {
      if (e.category) set.add(e.category);
    });
    return Array.from(set).sort();
  }, [liveEvents]);

  // Filtered dataset
  const filteredEvents = useMemo(() => {
    let list = liveEvents.filter((e) => {
      if (categoryFilter !== 'ALL' && e.category?.toLowerCase() !== categoryFilter.toLowerCase()) {
        return false;
      }
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase().trim();
        const matchesApp = e.app_name?.toLowerCase().includes(q);
        const matchesTitle = e.window_title?.toLowerCase().includes(q);
        const matchesCat = e.category?.toLowerCase().includes(q);
        if (!matchesApp && !matchesTitle && !matchesCat) return false;
      }
      return true;
    });

    if (sortOrder === 'newest') {
      list = [...list].reverse();
    }
    return list;
  }, [liveEvents, categoryFilter, searchQuery, sortOrder]);

  // Pagination calculation
  const totalItems = filteredEvents.length;
  const totalPages = Math.ceil(totalItems / pageSize) || 1;
  const paginatedEvents = useMemo(() => {
    const start = (currentPage - 1) * pageSize;
    return filteredEvents.slice(start, start + pageSize);
  }, [filteredEvents, currentPage, pageSize]);

  // Export to CSV
  const handleExportCSV = () => {
    const headers = [
      'Date',
      'Timestamp',
      'Application',
      'Window Title',
      'Category',
      'Dwell (ms)',
      'Dwell (seconds)',
      'Keypress Count',
    ];
    const rows = filteredEvents.map((e) => [
      `"${e.date || (e.recorded_at ? new Date(e.recorded_at).toLocaleDateString() : 'Today')}"`,
      `"${e.timestamp || ''}"`,
      `"${(e.app_name || '').replace(/"/g, '""')}"`,
      `"${(e.window_title || '').replace(/"/g, '""')}"`,
      `"${e.category || 'Unclassified'}"`,
      e.dwell_ms || 0,
      Math.round((e.dwell_ms || 0) / 1000),
      e.keyboard_events || e.keys || e.key_count || 0,
    ]);

    const csvContent =
      'data:text/csv;charset=utf-8,' +
      [headers.join(','), ...rows.map((r) => r.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute(
      'download',
      `chronotrace_raw_activity_${new Date().toISOString().slice(0, 10)}.csv`
    );
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const formatDwell = (ms: number) => {
    if (!ms) return '0s';
    const seconds = Math.round(ms / 1000);
    if (seconds >= 60) {
      const mins = Math.floor(seconds / 60);
      const remSec = seconds % 60;
      return `${mins}m ${remSec}s`;
    }
    return `${seconds}s`;
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h1 className="text-xl font-bold tracking-tight text-slate-900 leading-none">
            Raw Activity Log
          </h1>
          <p className="text-xs text-slate-500 mt-1">
            Auditable log of permitted foreground window events captured by your local workstation collector
          </p>
        </div>

        <button
          onClick={handleExportCSV}
          className="inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg text-xs font-medium bg-white hover:bg-slate-50 border border-slate-200 text-slate-700 shadow-2xs transition-colors cursor-pointer self-start sm:self-auto"
        >
          <Download className="w-3.5 h-3.5 text-slate-500" />
          <span>Export CSV</span>
        </button>
      </div>

      {/* Accurate Privacy Compliance Guarantee Banner */}
      <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200/90 flex items-start gap-2.5 text-xs text-slate-600">
        <Shield className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
        <div className="space-y-1">
          <p className="leading-relaxed">
            <strong className="text-slate-900 font-semibold">Privacy Compliance:</strong> All data is sampled locally via Windows foreground hooks. ChronoTrace records only foreground application names, window titles, exact timestamps, dwell duration, and typing activity frequency counters.
          </p>
          <p className="text-slate-500 text-[11px]">
            Keystroke characters, passwords, documents, clipboard content, personal messages, and screenshots are never observed, recorded, or transmitted.
          </p>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="bg-white border border-slate-200 rounded-xl p-3.5 shadow-2xs flex flex-col sm:flex-row items-center justify-between gap-3">
        {/* Search Input */}
        <div className="relative flex-1 w-full">
          <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => {
              setSearchQuery(e.target.value);
              setCurrentPage(1);
            }}
            placeholder="Search by window title, application name, or category..."
            className="w-full pl-9 pr-3 py-2 text-xs rounded-lg border border-slate-200 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent text-slate-900 placeholder:text-slate-400"
          />
        </div>

        {/* Category Filter */}
        <div className="flex items-center gap-2 w-full sm:w-auto">
          <div className="flex items-center gap-1.5 text-xs text-slate-500 shrink-0">
            <Filter className="w-3.5 h-3.5" />
            <span>Category:</span>
          </div>
          <select
            value={categoryFilter}
            onChange={(e) => {
              setCategoryFilter(e.target.value);
              setCurrentPage(1);
            }}
            className="text-xs border border-slate-200 rounded-lg px-2.5 py-2 text-slate-700 bg-white focus:outline-none focus:ring-2 focus:ring-blue-500 cursor-pointer"
          >
            <option value="ALL">All Categories</option>
            {categories.map((c) => (
              <option key={c} value={c}>
                {c}
              </option>
            ))}
          </select>
        </div>

        {/* Sort Order */}
        <div className="flex items-center gap-2 w-full sm:w-auto">
          <select
            value={sortOrder}
            onChange={(e) => {
              setSortOrder(e.target.value as 'newest' | 'oldest');
              setCurrentPage(1);
            }}
            className="text-xs border border-slate-200 rounded-lg px-2.5 py-2 text-slate-700 bg-white focus:outline-none focus:ring-2 focus:ring-blue-500 cursor-pointer"
          >
            <option value="newest">Newest First</option>
            <option value="oldest">Oldest First</option>
          </select>
        </div>
      </div>

      {/* Table Container with visual association for consecutive events */}
      <div className="bg-white border border-slate-200 rounded-xl shadow-2xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 border-b border-slate-200 text-slate-600 font-semibold">
              <tr>
                <th className="py-3 px-4 w-36">Time &amp; Date</th>
                <th className="py-3 px-4 w-36">Application</th>
                <th className="py-3 px-4">Window Title</th>
                <th className="py-3 px-4 w-28">Category</th>
                <th className="py-3 px-4 w-24">Dwell</th>
                <th className="py-3 px-4 w-28">Typing Activity</th>
                <th className="py-3 px-4 w-16 text-right">Details</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {events.length === 0 ? (
                <tr>
                  <td colSpan={7} className="py-16 text-center text-slate-500">
                    <Database className="w-8 h-8 text-slate-300 mx-auto mb-2" />
                    <div className="font-semibold text-slate-800 text-sm">
                      No raw telemetry events recorded yet
                    </div>
                    <div className="text-xs text-slate-400 mt-1 max-w-sm mx-auto">
                      When the Windows telemetry agent is active, every foreground window change, application name, and dwell duration will be recorded here for auditing.
                    </div>
                    {onOpenDeviceModal && (
                      <button
                        onClick={onOpenDeviceModal}
                        className="mt-3 inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold bg-slate-900 text-white hover:bg-slate-800 cursor-pointer"
                      >
                        Connect Device
                      </button>
                    )}
                  </td>
                </tr>
              ) : paginatedEvents.length === 0 ? (
                <tr>
                  <td colSpan={7} className="py-12 text-center text-slate-500">
                    <HelpCircle className="w-6 h-6 text-slate-300 mx-auto mb-2" />
                    <span>No raw activity events match your filter criteria</span>
                  </td>
                </tr>
              ) : (
                paginatedEvents.map((evt, idx) => {
                  // Determine if consecutive with previous event in current page view
                  const prevEvt = idx > 0 ? paginatedEvents[idx - 1] : null;
                  const isConsecutiveSameWindow =
                    prevEvt !== null &&
                    prevEvt.app_name === evt.app_name &&
                    prevEvt.window_title === evt.window_title;

                  const keyCount = evt.keyboard_events ?? evt.keys ?? evt.key_count ?? 0;

                  return (
                    <tr
                      key={idx}
                      className={`hover:bg-slate-50/80 transition-colors ${
                        isConsecutiveSameWindow ? 'bg-slate-50/30' : ''
                      }`}
                    >
                      <td className="py-2.5 px-4 whitespace-nowrap">
                        <div className="font-mono font-medium text-slate-900 tabular-nums">
                          {evt.timestamp}
                        </div>
                        <div className="text-[10px] text-slate-400">
                          {evt.date || (evt.recorded_at ? new Date(evt.recorded_at).toLocaleDateString() : 'Today')}
                        </div>
                      </td>

                      <td className="py-2.5 px-4 font-medium text-slate-900 whitespace-nowrap">
                        {isConsecutiveSameWindow ? (
                          <div className="flex items-center gap-1.5 text-slate-400 text-xs">
                            <span className="w-1.5 h-1.5 rounded-full bg-slate-300 ml-1" />
                            <span className="text-slate-600">{evt.app_name}</span>
                          </div>
                        ) : (
                          <div className="flex items-center gap-1.5">
                            <span className="w-1.5 h-1.5 rounded-full bg-blue-500" />
                            <span>{evt.app_name}</span>
                          </div>
                        )}
                      </td>

                      <td className="py-2.5 px-4 text-slate-700 max-w-sm truncate" title={evt.window_title}>
                        {isConsecutiveSameWindow ? (
                          <div className="flex items-center gap-1.5 text-slate-500 font-mono text-[11px] truncate">
                            <CornerDownRight className="w-3 h-3 text-slate-400 shrink-0" />
                            <span className="truncate" title={evt.window_title}>
                              {evt.window_title}
                            </span>
                          </div>
                        ) : (
                          <span className="font-mono text-[11px] truncate block" title={evt.window_title}>
                            {evt.window_title}
                          </span>
                        )}
                      </td>

                      <td className="py-2.5 px-4 text-slate-600 whitespace-nowrap">
                        <span className="text-[11px] font-medium text-slate-700">
                          {evt.category || 'Unclassified'}
                        </span>
                      </td>

                      <td className="py-2.5 px-4 font-mono tabular-nums text-slate-600 whitespace-nowrap">
                        {formatDwell(evt.dwell_ms)}
                      </td>

                      <td className="py-2.5 px-4 text-slate-500 font-mono tabular-nums whitespace-nowrap">
                        {keyCount > 0 ? (
                          <span className="text-slate-700 font-medium">{keyCount} keys</span>
                        ) : (
                          <span className="text-slate-400">0 keys</span>
                        )}
                      </td>

                      <td className="py-2.5 px-4 text-right whitespace-nowrap">
                        <button
                          onClick={() => setSelectedEvent(evt)}
                          title="View Event Details"
                          className="text-blue-600 hover:text-blue-800 font-medium p-1 rounded hover:bg-blue-50 cursor-pointer"
                        >
                          <Eye className="w-3.5 h-3.5 inline" />
                        </button>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>

        {/* Pagination controls */}
        <div className="p-3.5 border-t border-slate-200 bg-slate-50/60 flex items-center justify-between text-xs text-slate-600">
          <div>
            Showing{' '}
            <span className="font-semibold text-slate-900 font-mono tabular-nums">
              {totalItems === 0 ? 0 : (currentPage - 1) * pageSize + 1}
            </span>{' '}
            to{' '}
            <span className="font-semibold text-slate-900 font-mono tabular-nums">
              {Math.min(currentPage * pageSize, totalItems)}
            </span>{' '}
            of <span className="font-semibold text-slate-900 font-mono tabular-nums">{totalItems}</span> events
          </div>

          <div className="flex items-center gap-1.5">
            <button
              onClick={() => setCurrentPage((p) => Math.max(1, p - 1))}
              disabled={currentPage <= 1}
              className="p-1.5 rounded-lg border border-slate-200 bg-white hover:bg-slate-50 disabled:opacity-40 disabled:cursor-not-allowed cursor-pointer"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>
            <span className="px-2 font-medium font-mono tabular-nums">
              Page {currentPage} of {totalPages}
            </span>
            <button
              onClick={() => setCurrentPage((p) => Math.min(totalPages, p + 1))}
              disabled={currentPage >= totalPages}
              className="p-1.5 rounded-lg border border-slate-200 bg-white hover:bg-slate-50 disabled:opacity-40 disabled:cursor-not-allowed cursor-pointer"
            >
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>

      {/* Event Details Slide-Over Modal */}
      {selectedEvent && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/40 p-4">
          <div className="bg-white border border-slate-200 rounded-2xl max-w-lg w-full p-6 shadow-xl relative animate-in fade-in zoom-in-95 duration-150">
            <div className="flex items-center justify-between mb-4 pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <Database className="w-4 h-4 text-blue-600" />
                <h3 className="font-semibold text-slate-900 text-sm">Permitted Event Inspection</h3>
              </div>
              <button
                onClick={() => setSelectedEvent(null)}
                className="text-slate-400 hover:text-slate-600 p-1 rounded cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-3 text-xs">
              <div className="bg-slate-50 p-3.5 rounded-xl border border-slate-200/80 space-y-2">
                <div className="flex justify-between">
                  <span className="text-slate-500">Timestamp:</span>
                  <span className="font-mono font-semibold text-slate-900 tabular-nums">
                    {selectedEvent.timestamp}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Date:</span>
                  <span className="text-slate-900">
                    {selectedEvent.date || (selectedEvent.recorded_at ? new Date(selectedEvent.recorded_at).toLocaleDateString() : 'Today')}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Application Executable:</span>
                  <span className="font-semibold text-slate-900">{selectedEvent.app_name}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Category Tag:</span>
                  <span className="font-semibold text-blue-700">{selectedEvent.category}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Foreground Dwell:</span>
                  <span className="font-mono tabular-nums text-slate-800">
                    {formatDwell(selectedEvent.dwell_ms)} ({selectedEvent.dwell_ms}ms)
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Typing Counter:</span>
                  <span className="font-mono tabular-nums text-slate-800">
                    {selectedEvent.keyboard_events ?? selectedEvent.keys ?? selectedEvent.key_count ?? 0} keypresses
                  </span>
                </div>
              </div>

              <div>
                <span className="text-slate-500 block mb-1 font-medium">Observed Foreground Window Title:</span>
                <div className="p-3 bg-slate-100/70 rounded-lg text-slate-800 font-mono text-[11px] break-all border border-slate-200/60">
                  {selectedEvent.window_title}
                </div>
              </div>

              <div className="p-3 rounded-lg bg-emerald-50 border border-emerald-100 text-[11px] text-emerald-800 flex items-start gap-2">
                <Shield className="w-3.5 h-3.5 text-emerald-600 shrink-0 mt-0.5" />
                <span>
                  No typed text, passwords, or screenshots were collected. ChronoTrace samples strictly window title metadata and key counters.
                </span>
              </div>
            </div>

            <div className="mt-5 flex justify-end">
              <button
                onClick={() => setSelectedEvent(null)}
                className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-medium rounded-lg text-xs cursor-pointer transition-colors"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
